# SPDX-FileCopyrightText: 2026 M0Rf30
# SPDX-License-Identifier: MIT

"""Plugin entry point for plugin.video.revrivulet.

Kodi invokes this script directly (not as an import), passing the
plugin:// invocation as sys.argv. Bootstrap sys.path so the addon's own
``lib`` package is importable, then either open the custom HomeWindow
(a bare invocation - clicking the addon - is Rivulet's own app UI now)
or hand off to the router for every other action (context-menu
RunPlugin callbacks, Settings buttons, ``play``, ...).
"""
import os
import sys
from urllib.parse import parse_qs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from lib.addonid import ADDON_ID
from lib.ui import router, urlutil

router.BASE_URL = sys.argv[0] if len(sys.argv) > 0 else 'plugin://%s/' % ADDON_ID
try:
    router.ADDON_HANDLE = int(sys.argv[1])
except (IndexError, ValueError):
    router.ADDON_HANDLE = -1

_raw_qs = sys.argv[2] if len(sys.argv) > 2 else ''
if _raw_qs.startswith('?'):
    _raw_qs = _raw_qs[1:]
_action = parse_qs(_raw_qs).get('action', ['home'])[0]

if _action == 'home':
    import xbmc
    import xbmcplugin

    from lib.ui.compat import log

    # Kodi's GetDirectory contract for this handle must be satisfied exactly
    # once (an empty, instant directory) before the custom window takes over
    # the screen - see lib.ui.uicommon's module docstring.
    xbmcplugin.endOfDirectory(
        router.ADDON_HANDLE, succeeded=True, updateListing=False, cacheToDisc=False
    )
    try:
        from lib.ui.homewindow import open_home
        from lib.ui.uicommon import dismiss_busy_dialog, is_duplicate_launch

        if is_duplicate_launch():
            # Kodi re-ran the plugin root (it re-fetches the Videos container
            # the addon was started from whenever that window is activated
            # again - e.g. when playback stops: kodi.log 01:07:59.987 ->
            # 01:08:00.189) while another interpreter's UI is alive. Any
            # fresh heartbeat counts, including while a video is still
            # reported as playing and the phase already reads `addon`.
            # The directory handle is satisfied above. Opening Home here
            # would stack a second UI over the restored picker, and
            # dismiss_busy_dialog() is Dialog.Close(all), which would
            # close that picker without marking it for restore. See
            # lib.ui.uicommon.is_duplicate_launch().
            log('default: a Rivulet UI is already running - ignoring bare launch', xbmc.LOGINFO)
        else:
            dismiss_busy_dialog()
            open_home()
    except Exception as exc:  # the custom UI must never leave the addon unusable
        log(
            'default: HomeWindow failed, falling back to classical home: %r' % (exc,),
            xbmc.LOGERROR,
        )
        # 'home_classical' is intentionally NOT a registered router action:
        # this is a FRESH plugin:// invocation (its own handle), and
        # router.run()'s dispatch falls back to views.home() - now a
        # minimal recovery directory (notice + Settings row), not the
        # classical home - for any unrecognized action; see router.run()'s
        # `dispatch.get(action, dispatch['home'])`. This handle was already
        # closed above, so recovery must go through a new invocation rather
        # than a second endOfDirectory() call on the same (spent) handle.
        fallback_url = urlutil.url_for(router.BASE_URL, 'home_classical')
        xbmc.executebuiltin('Container.Update(%s)' % fallback_url)
else:
    router.run()
