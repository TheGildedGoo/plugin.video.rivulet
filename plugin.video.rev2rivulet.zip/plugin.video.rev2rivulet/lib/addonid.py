# SPDX-FileCopyrightText: 2026 M0Rf30
# SPDX-License-Identifier: MIT

"""Identity of this fork.

Official Rivulet stays installed beside this addon. Skin XML, settings.xml,
addon.xml and the Stream4Me bridge cannot import this module (Kodi reads
those as data, and the bridge is launched by RunScript with only its own
directory on sys.path). Those files repeat ADDON_ID literally.
tests/test_revrivulet_identity.py fails if they drift.
"""

ADDON_ID = "plugin.video.rev2rivulet"
ADDON_NAME = "Rev2Rivulet"
#: On-screen wordmark. Mixed case on purpose: the corner label reads
#: Rev2Rivulet, and nothing in the skin uppercases it.
WORDMARK = "Rev2Rivulet"
