# SPDX-License-Identifier: GPL-3.0-only
#
# Copyright (C) 2026 the Rivulet contributors
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.
"""Pure, Kodi-independent AND Stream4Me-independent logic for the S4Me
bridge (`bridge.py`, in this same directory).

Licensed GPL-3, unlike the rest of this MIT-licensed addon: this whole
`resources/s4me_bridge/` directory only exists to glue into the GPL-3
Stream4Me (`plugin.video.s4me`) addon at runtime, and ships as an
opt-in-only feature (see `s4me_enable` in `resources/settings.xml`).

This module is deliberately its OWN copy of the request/response shaping
logic, rather than importing `lib.s4me` (Rivulet's `lib` package) or
anything from Stream4Me itself:

  - `bridge.py` runs as a separate `RunScript()` invocation with
    Stream4Me's own root (and its vendored `lib/`) prepended to
    `sys.path` so ITS internal `from core import ...`/`from lib import
    ...` absolute imports resolve. Rivulet's addon root also ships a
    top-level `lib` package of its own -- if `bridge.py` ever imported it
    (`from lib import s4me`) while Stream4Me's `lib/` sits earlier on
    `sys.path`, `import lib` would silently resolve to WHICHEVER of the
    two happened to be found first, depending on path order and import
    cache state. The only reliable fix is to never let this process
    import a module literally named `lib` that belongs to Rivulet at all.
  - Being self-contained also keeps this module importable and testable
    (see `tests/test_s4me_bridge_helpers.py`) with neither Kodi nor
    Stream4Me installed -- exactly the guarantee `lib/s4me.py` itself
    keeps for Rivulet's own side of this feature.

`MANIFEST` here is kept in sync BY HAND with `lib/s4me.MANIFEST` -- see
that module's docstring. `tests/test_s4me.py` and
`tests/test_s4me_bridge_helpers.py` both assert the two are identical,
which pins them together across any future edit to either.

`bridge.py` also serves two small non-Stremio routes this module's
helpers back: `POST /shutdown` (a clean-exit request `lib.s4me
.shutdown_bridge()` sends a stale bridge before relaunching it -- see
`ChannelBackoff` and `generate_play_key()`'s own docstrings for the two
pure pieces involved) and `GET /play/<key>`, which `generate_play_key()`
and `TTLCache` back for mega's deferred, on-demand resolve (see
`bridge.py`'s own `_shape_mega_stream()`/`_resolve_mega_play()` for why
mega cannot resolve at LIST time like every other server).
"""
import re
import secrets
import threading
import time
import unicodedata
from collections import OrderedDict
from concurrent.futures import TimeoutError as _FuturesTimeoutError
from concurrent.futures import as_completed
from concurrent.futures import wait as _futures_wait
from urllib.parse import parse_qsl

#: Stremio addon manifest this bridge serves at `/manifest.json` -- see
#: this module's docstring for why it is a second, hand-synced copy of
#: `lib.s4me.MANIFEST` rather than an import of it.
MANIFEST = {
    "id": "org.rivulet.s4me",
    "name": "Stream4Me",
    "version": "1.1.0",
    "description": (
        "Bridges the Stream4Me (S4Me) Kodi addon's Italian channel "
        "scrapers into the Stremio protocol."
    ),
    "resources": ["stream"],
    "types": ["movie", "series"],
    "idPrefixes": ["tt"],
    "catalogs": [],
}

#: A Stremio stream request id is either a bare IMDb id ("tt1234567", for
#: a movie) or an IMDb id plus 1-based season/episode ("tt1234567:1:2",
#: for a series episode) -- see https://github.com/Stremio/stremio-addon-sdk
#: "Request stream" for the wire format this matches.
_STREAM_ID_RE = re.compile(r"^(tt\d+)(?::(\d+):(\d+))?$")


#: Functions Kodi 19 moved from `xbmc` to `xbmcvfs` (and Kodi 20+ removed
#: from `xbmc`) that Stream4Me still calls through `xbmc`.
MOVED_XBMC_FUNCTIONS = ("translatePath", "validatePath", "makeLegalFilename")


def restore_moved_xbmc_functions(xbmc_mod, xbmcvfs_mod):
    """Copy `MOVED_XBMC_FUNCTIONS` from `xbmcvfs_mod` onto `xbmc_mod`,
    exactly as Stream4Me's own entry points do before importing its code.
    Only fills in what `xbmc_mod` lacks and `xbmcvfs_mod` has, so it never
    replaces a working function. Returns the names it restored."""
    restored = []
    for name in MOVED_XBMC_FUNCTIONS:
        if not hasattr(xbmc_mod, name) and hasattr(xbmcvfs_mod, name):
            setattr(xbmc_mod, name, getattr(xbmcvfs_mod, name))
            restored.append(name)
    return restored


def parse_stream_id(id_):
    """Split a Stremio `/stream/{type}/{id}.json` id into `(imdb_id,
    season, episode)` -- `season`/`episode` are `None` for a movie id.
    Returns `None` for anything that doesn't match the expected shape
    (never raises)."""
    match = _STREAM_ID_RE.match((id_ or "").strip())
    if not match:
        return None
    imdb_id, season, episode = match.groups()
    return imdb_id, (int(season) if season else None), (int(episode) if episode else None)


def split_kodi_url(raw):
    """Split a Stream4Me server-item url's Kodi-style
    `"url|Header=value&Header2=value2"` shape into `(url, headers)`.

    No `|` present -> `(raw, {})`. Header values are `%`-decoded (Stream4Me
    encodes them with `urllib.parse.urlencode`, the standard Kodi
    resolved-url convention for per-request headers); a malformed/empty
    header segment yields an empty headers dict, never raises. `raw is
    None` -> `("", {})`.
    """
    if raw is None:
        return "", {}
    url, sep, query = raw.partition("|")
    if not sep or not query:
        return url, {}
    headers = dict(parse_qsl(query, keep_blank_values=True))
    return url, headers


def normalize_title(text):
    """Lowercase, accent-stripped, punctuation-collapsed form of `text`,
    for fallback title+year matching when a search result's infoLabels
    carries no `tmdb_id`."""
    if not text:
        return ""
    decomposed = unicodedata.normalize("NFKD", text)
    stripped = "".join(ch for ch in decomposed if not unicodedata.combining(ch))
    return re.sub(r"[^a-z0-9]+", " ", stripped.lower()).strip()


def tmdb_id_matches(candidate_tmdb_id, target_tmdb_id):
    """True if both identify the same, present TMDB id. A missing/empty
    `target_tmdb_id` never matches anything (there is nothing to confirm
    against), so callers fall back to `title_matches()` in that case."""
    if not target_tmdb_id:
        return False
    candidate = str(candidate_tmdb_id or "")
    return candidate != "" and candidate == str(target_tmdb_id)


def title_matches(candidate_title, candidate_year, target_title, target_year):
    """Fallback match when no `tmdb_id` is available on either side:
    normalized titles must be equal, and if BOTH sides carry a year, it
    must match too (a missing year on either side is not a mismatch --
    plenty of scraped titles carry no year at all)."""
    candidate_norm = normalize_title(candidate_title)
    if not candidate_norm or candidate_norm != normalize_title(target_title):
        return False
    if candidate_year and target_year:
        return str(candidate_year) == str(target_year)
    return True


def result_matches(info_labels, target_tmdb_id, target_title, target_year):
    """True if `info_labels` (a Stream4Me `Item.infoLabels`-like mapping)
    identifies the same title as `target_tmdb_id`/`target_title`/
    `target_year` -- `tmdb_id` first, normalized title+year fallback.

    The title+year fallback only applies when at least one side lacks a
    `tmdb_id`: if both carry one and `tmdb_id_matches()` above already
    said they differ, an equal title+year is a same-name coincidence
    (e.g. a remake), not the same title, and must not override that."""
    info_labels = info_labels or {}
    candidate_tmdb_id = info_labels.get("tmdb_id")
    if tmdb_id_matches(candidate_tmdb_id, target_tmdb_id):
        return True
    if candidate_tmdb_id and target_tmdb_id:
        return False
    return title_matches(
        info_labels.get("title") or info_labels.get("originaltitle"),
        info_labels.get("year"),
        target_title,
        target_year,
    )



def content_type_for_s4me(content_type):
    """Map a Stremio content type to the value Stream4Me's own
    `Item(contentType=...)` understands.

    Stream4Me's `core.item.InfoLabels` stores `contentType` as
    `infoLabels.mediatype`, and silently downgrades any value outside
    `{"list", "movie", "tvshow", "season", "episode", "music",
    "undefined"}` to `"list"` -- so Stremio's own `"series"` must become
    `"tvshow"` here, or a channel that branches on the item's media type
    searches in the wrong mode and misses every series result. Every
    other content type (currently only `"movie"`) already matches
    Stream4Me's vocabulary and passes through unchanged."""
    return "tvshow" if content_type == "series" else content_type


def label_value_or(label_value, fallback_value):
    """`label_value` if present, else `fallback_value`.

    "Present" means not `None` and not `""` -- NOT merely truthy: a
    Stream4Me `infoLabels` season/episode of `0` (a special/extra) is a
    valid, present value and must be kept, unlike a bare `x or fallback`
    which would treat `0` as missing."""
    return label_value if label_value not in (None, "") else fallback_value


def pick_episode(episodes, season, episode):
    """The single episode Item within `episodes` (a channel's own
    `episodios()` result) matching `(season, episode)`, or `None`.

    Split out of the `episodios()` CALL itself (`bridge.py`'s
    `_episodes_list()`) so the list can be cached at show level -- see
    `match_cache_key()` -- while this pure season/episode match stays
    independently testable."""
    for ep_item in episodes or []:
        ep_labels = getattr(ep_item, "infoLabels", {}) or {}
        ep_season = str(label_value_or(
            ep_labels.get("season"), getattr(ep_item, "season", ""),
        ))
        ep_episode = str(label_value_or(
            ep_labels.get("episode"), getattr(ep_item, "episode", ""),
        ))
        if ep_season == str(season) and ep_episode == str(episode):
            return ep_item
    return None


def shape_stream(
    channel, server_name, url, headers=None, quality=None, adaptive_hint=None, subtitle_url=None,
    drm=None,
):
    """Build one Stremio `stream` object (an entry of the
    `/stream/{type}/{id}.json` response's `streams[]` array) from one
    resolved Stream4Me play url.

    `name` is always `"S4Me <channel>"` (Stremio groups streams by
    `name` in its UI, so every stream from one channel visually groups
    together); `title` carries the more specific per-result detail
    (server/quality) users actually pick between.

    `adaptive_hint` (`"hls"`/`"mpd"`/`None`, see `adaptive_manifest_type()`)
    becomes `behaviorHints.rivuletManifestType` -- Rivulet's own player
    reads it to pick inputstream.adaptive over a direct play, falling
    back to sniffing the url's `.m3u8`/`.mpd` suffix only when it is
    absent. `subtitle_url` (see `subtitle_url_from_entry()`) becomes a
    single-entry `subtitles` array in the Stremio wire shape. `drm` (see
    `drm_hint()`) becomes `behaviorHints.rivuletDrm`.
    """
    title_bits = [bit for bit in (server_name, quality) if bit]
    stream = {
        "name": "S4Me %s" % channel,
        "title": " - ".join(title_bits) if title_bits else channel,
        "url": url,
    }
    behavior_hints = {}
    if headers:
        # notWebReady + proxyHeaders.request is the Stremio convention for
        # a direct-play url that needs custom request headers (referer/
        # cookie/user-agent) - see stremio-core's StreamBehaviorHints.
        behavior_hints["notWebReady"] = True
        behavior_hints["proxyHeaders"] = {"request": dict(headers)}
    if adaptive_hint:
        behavior_hints["rivuletManifestType"] = adaptive_hint
    if drm:
        behavior_hints["rivuletDrm"] = dict(drm)
    if behavior_hints:
        stream["behaviorHints"] = behavior_hints
    if subtitle_url:
        stream["subtitles"] = [{"id": subtitle_url, "url": subtitle_url, "lang": "ita"}]
    return stream


def drm_hint(drm_type, license_key):
    """`{"type", "license"}` for Rivulet's player from a Stream4Me item's
    `drm`/`license` fields, or `None` when either is missing.

    Stream4Me sets them on items whose DASH is encrypted (Pluto TV:
    `com.widevine.alpha` plus a license url carrying its own header and
    `R{SSM}` request template) and hands both to inputstream.adaptive.
    Without them ISA refuses the stream outright ("Unhandled encrypted
    stream", observed live)."""
    if isinstance(drm_type, str) and drm_type and isinstance(license_key, str) and license_key:
        return {"type": drm_type, "license": license_key}
    return None


#: Stream4Me servers whose resolved url is unplayable outright, and no
#: on-demand deferral (like mega's, see `bridge.py`'s
#: `_shape_mega_stream()`) exists for them yet. Empty today: `mega` used
#: to be the sole member (its megaserver proxy dies ~20s after this
#: bridge resolved it at LIST time, and a second concurrent resolve
#: clobbered `servers/mega.py`'s own module-global file list -- "Il
#: padrino" was served "Le ali della libertà") -- kept as a real,
#: `is_servable()`-checked set rather than deleted outright so a FUTURE
#: server with no viable deferral has an established place to be listed
#: instead of a bespoke special case.
UNSERVABLE_SERVERS = frozenset()  # type: frozenset


def is_servable(server, url):
    """Whether a `(server, url)` Stream4Me server item can become a
    playable Stremio stream. `UNSERVABLE_SERVERS` never can (see its own
    docstring). A `torrent` item only can as a `magnet:` url, which
    Rivulet hands to the streaming server; a `.torrent` http url is the
    torrent FILE, which Kodi would try (and fail) to play as video."""
    if server in UNSERVABLE_SERVERS:
        return False
    if server == "torrent":
        return (url or "").startswith("magnet:")
    return True


def is_adaptive_entry(entry, manifest=None):
    """Whether Stream4Me would play one `video_urls` entry (`[label, url,
    ...]`) through inputstream.adaptive, per its own
    `platformtools.get_video_seleccionado()`/`play_video()`: `mpd`/`hls`
    in the label, a five-field entry, or the item's `manifest`."""
    label = entry[0] if entry and isinstance(entry[0], str) else ""
    return (
        "mpd" in label or "hls" in label or len(entry) > 4
        or manifest in ("mpd", "hls")
    )


def adaptive_manifest_type(entry, manifest=None):
    """Which inputstream.adaptive manifest type one ALREADY-adaptive
    `video_urls` entry (see `is_adaptive_entry()` -- call this only when
    that already returned `True`) uses: `"mpd"` if its label mentions
    mpd, it carries the five-field shape (a trailing DRM license after
    the subtitle field), or the item's own `manifest` says so; `"hls"`
    otherwise, Stream4Me's only other adaptive shape. Becomes
    `behaviorHints.rivuletManifestType` in `shape_stream()` -- see the
    Rivulet player's own fallback-to-url-suffix docstring for why this
    hint exists at all."""
    label = entry[0] if entry and isinstance(entry[0], str) else ""
    if "mpd" in label or len(entry) > 4 or manifest == "mpd":
        return "mpd"
    return "hls"


def subtitle_url_from_entry(entry):
    """The subtitle url one `video_urls` entry carries at index 3 (`[label,
    url, 0, subtitle]`, Stream4Me's own `platformtools.play_video()`
    convention of handing that field straight to Kodi's
    `ListItem.setSubtitles()`), or `None` when that field is missing, not
    a string, or not a non-empty `http(s)` url -- some entries reuse
    index 3 for an unrelated flag, and a non-url value there must never
    become a bogus Stremio `subtitles[].url`."""
    if not entry or len(entry) < 4:
        return None
    candidate = entry[3]
    if isinstance(candidate, str) and candidate.startswith(("http://", "https://")):
        return candidate
    return None


def playback_headers(server, page_url, referer, resolved_headers, user_agent, adaptive=False):
    """The request headers the player must send for one resolved url,
    mirroring Stream4Me's own `platformtools.play_video()`.

    Its defaults are a browser User-Agent plus a Referer of the server
    page (`referer` instead for a `directo` item). A progressive url gets
    them only when the resolver attached none of its own (`url|Header=...`,
    which then win outright) and the item did not set `referer` to
    `False`. An adaptive (HLS/DASH) url ALWAYS gets them -- Stream4Me
    hands them to inputstream.adaptive regardless of `referer` -- with any
    resolver headers layered on top.

    Not optional: vixcloud (every StreamingCommunity stream, whose channel
    sets `referer=False`) and Pluto TV answer Kodi's own `Kodi/21.x`
    User-Agent with 403 and serve the same url to a browser one."""
    if not adaptive:
        if resolved_headers:
            return dict(resolved_headers)
        if referer is False:
            return {}
    headers = {}
    if user_agent:
        headers["User-Agent"] = user_agent
    chosen_referer = referer if server == "directo" and referer else page_url
    if chosen_referer:
        headers["Referer"] = chosen_referer
    headers.update(resolved_headers or {})
    return headers


def guard_video_check(check):
    """Wrap a Stream4Me server module's `test_video_exists()` so a raised
    exception reads as "video does not exist" instead of "exists".

    `core.servertools.resolve_video_urls_for_playing()` swallows an
    exception from that check but leaves `video_exists = True`, then calls
    `get_video_url()` -- which, for servers that hand state from the check
    to the resolve through module globals (`mega`'s `files`,
    `streamingcommunityws`'s `iframeParams`), returns whatever the
    PREVIOUS successful check left behind: another title's stream. In
    Stream4Me that needs two plays in one session; in this long-lived
    bridge it is routine. Idempotent: an already-guarded check is returned
    unchanged."""
    if getattr(check, "_rivulet_guarded", False):
        return check

    def guarded(*args, **kwargs):
        try:
            return check(*args, **kwargs)
        except Exception as exc:  # noqa: BLE001 - any failure means "no usable video"
            return False, "video check failed: %r" % (exc,)

    guarded._rivulet_guarded = True
    return guarded


class KeyedLocks:
    """One `threading.Lock` per key, created on first use.

    The bridge serializes resolves per Stream4Me server with these:
    server modules pass state from `test_video_exists()` to
    `get_video_url()` through module globals, so two threads resolving the
    same server at once can each read the other's result."""

    def __init__(self):
        self._locks = {}
        self._guard = threading.Lock()

    def lock_for(self, key):
        with self._guard:
            return self._locks.setdefault(key, threading.Lock())


def generate_play_key():
    """A fresh, unguessable id for one bridge-issued `/play/<key>` mega
    redirect (see `bridge.py`'s `_shape_mega_stream()`/`_resolve_mega_play()`
    for the full deferred-resolve design this backs). `secrets.token_urlsafe`
    keeps it filesystem/URL-safe and cryptographically unguessable (CWE-330
    -- this bridge binds to `127.0.0.1` only, but ANY local process or
    browser tab can still reach it, and a guessable key would let one
    hijack another request's deferred mega resolve)."""
    return secrets.token_urlsafe(16)


def build_manifest():
    """Return a fresh copy of `MANIFEST` -- callers may safely mutate
    their own copy without risk of corrupting the module-level constant
    (e.g. serializing it straight into an HTTP response body)."""
    return dict(MANIFEST)


def parse_channels_setting(raw):
    """Parse the `s4me_channels` comma-list setting into a tuple of
    stripped, non-empty channel ids, or `None` when blank -- `None` means
    "use every one of Stream4Me's own active channels" rather than a
    fixed allow-list. Identical logic to `lib.s4me.parse_channels_setting`
    (duplicated here on purpose -- see this module's docstring)."""
    if not raw or not raw.strip():
        return None
    return tuple(c.strip() for c in raw.split(",") if c.strip())


def select_channels(configured, active_channels):
    """Resolve the actual channel ids to search for one request.

    `configured` is `parse_channels_setting()`'s result: a tuple of
    explicit channel ids, or `None`. `active_channels` is the list of
    channel ids Stream4Me itself currently reports active (read from its
    `channels/<id>.json` `active` flags -- something only `bridge.py`
    itself knows how to determine, not this pure module).

    A `configured` id absent from `active_channels` is silently dropped
    (a stale/misspelled setting is never an error, just an empty
    contribution to the fan-out); `configured is None` returns every
    active channel unfiltered.
    """
    if configured is None:
        return tuple(active_channels)
    active_set = set(active_channels)
    return tuple(c for c in configured if c in active_set)


#: Stream4Me channel `categories` that can serve each Stremio content type.
#: Anime channels carry both films and series, so they count for either.
_CATEGORIES_FOR_TYPE = {
    "movie": frozenset({"movie", "anime"}),
    "series": frozenset({"tvshow", "anime"}),
}

_SEARCH_DEF_RE = re.compile(r"^def search\(", re.MULTILINE)


def defines_search(source):
    """Whether a Stream4Me channel module's source defines a top-level
    `search()` -- the only entry point the bridge calls. Channels without
    one (live TV, radio) would only fail with AttributeError on every
    request. Matching the source, not importing it, keeps the check free
    of each channel's module-level side effects."""
    return bool(_SEARCH_DEF_RE.search(source or ""))


def channels_for_type(channels, content_type):
    """Ids of the channels worth searching for a Stremio `content_type`.

    `channels` is `(id, categories, has_search)` per active channel. A
    channel is kept when it defines `search()` and either declares a
    category serving `content_type` or declares no categories at all (so
    an untagged channel is not silently lost). An unknown content type
    keeps every searchable channel."""
    wanted = _CATEGORIES_FOR_TYPE.get(content_type)
    selected = []
    for channel_id, categories, has_search in channels:
        if not has_search:
            continue
        if wanted is None or not categories or wanted & set(categories):
            selected.append(channel_id)
    return tuple(selected)


def match_cache_key(channel_id, content_type, tmdb_id, title, year):
    """Cache key for one channel's per-show/movie search match -- see
    `bridge.py`'s `_MATCH_CACHE`/`_streams_for_channel()` for why this is
    cached independent of season/episode (a series' matched show item and
    its `episodios()` list are reused across every episode request).
    Prefers `tmdb_id` (the same, precise identity `result_matches()`
    itself prefers); falls back to a normalized title/year pair when
    absent, so two differently-cased/accented requests for the same
    untagged title still share one cache entry."""
    identity = str(tmdb_id) if tmdb_id else (normalize_title(title), str(year or ""))
    return (channel_id, content_type, identity)


class TTLCache:
    """Tiny per-key time-to-live cache. `clock` is injectable
    (`time.monotonic` in production) so tests can control expiry
    deterministically without sleeping.

    Bounded on two axes so a long-running bridge process's cache cannot
    grow without limit: `max_size` caps the number of distinct keys
    (oldest-inserted evicted first once exceeded), and every `set()`
    also sweeps out every already-expired entry -- not just the one
    key being written -- so a key that is never requested again (e.g. a
    title nobody re-queries) does not linger past its TTL just because
    `get()` is the only thing that used to notice expiry.

    Thread-safe: every public method holds one internal `threading.Lock`
    for its whole body. Every instance of this class the bridge keeps
    (`_BridgeState.cache`, the per-channel show/movie match cache, the
    mega `/play/<key>` registry) is shared across every concurrent
    request's worker threads, and `set()`'s own `_purge_expired()` sweep
    iterates the backing `OrderedDict` -- unprotected, a concurrent
    `get()`'s eviction on the very entry being iterated would raise
    `RuntimeError: dictionary changed size during iteration`."""

    def __init__(self, ttl_seconds, clock=time.monotonic, max_size=256):
        self._ttl = ttl_seconds
        self._clock = clock
        self._max_size = max_size
        self._store = OrderedDict()
        self._lock = threading.Lock()

    def get(self, key):
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return None
            expires_at, value = entry
            if self._clock() >= expires_at:
                self._store.pop(key, None)
                return None
            return value

    def set(self, key, value):
        with self._lock:
            self._purge_expired()
            self._store[key] = (self._clock() + self._ttl, value)
            self._store.move_to_end(key)
            while len(self._store) > self._max_size:
                self._store.popitem(last=False)

    def _purge_expired(self):
        # Caller must already hold self._lock.
        now = self._clock()
        expired = [k for k, (expires_at, _value) in self._store.items() if now >= expires_at]
        for k in expired:
            del self._store[k]

    def __len__(self):
        with self._lock:
            return len(self._store)


class Budget:
    """A wall-clock deadline `bridge.py`'s per-request channel fan-out
    races against: "return whatever finished within ~N seconds" instead
    of blocking on every channel. `clock` is injectable for tests."""

    def __init__(self, seconds, clock=time.monotonic):
        self._deadline = clock() + seconds
        self._clock = clock

    def remaining(self):
        return max(0.0, self._deadline - self._clock())

    def expired(self):
        return self._clock() >= self._deadline


class ChannelBackoff:
    """Tracks consecutive pipeline failures per Stream4Me channel id and
    puts a channel that reaches `failure_threshold` in a row into a
    `cooldown_seconds` timeout -- a channel that is actually down (dead
    host, broken code after an update) would otherwise still eat a
    fan-out slot on EVERY single request until someone notices and fixes
    it, wasting up to `_CHANNEL_IO_TIMEOUT_SECONDS` of wall-clock, and a
    worker thread, on a channel with no chance of ever returning a
    result. A channel that simply searched fine and found no match for
    THIS title is never penalized -- see `bridge.py`'s `_channel_task()`,
    the one place that decides "real breakage" from "legitimate miss" and
    calls `record_success()`/`record_failure()` accordingly.

    `clock` is injectable for deterministic tests. Thread-safe: one
    `threading.Lock` guards every method's body, since `bridge.py` runs
    one worker thread per channel per request, and two concurrent
    requests can update the same channel's counter at once."""

    def __init__(self, failure_threshold=3, cooldown_seconds=10 * 60, clock=time.monotonic):
        self._threshold = failure_threshold
        self._cooldown = cooldown_seconds
        self._clock = clock
        self._failures = {}
        self._cooldown_until = {}
        self._lock = threading.Lock()

    def is_available(self, channel_id):
        """False while `channel_id` is serving its cooldown. A channel
        never recorded, or whose cooldown deadline has passed, is
        available -- and a passed deadline also resets its failure
        count, so one more failure right after does not instantly
        re-trip a fresh cooldown."""
        with self._lock:
            deadline = self._cooldown_until.get(channel_id)
            if deadline is None:
                return True
            if self._clock() < deadline:
                return False
            self._cooldown_until.pop(channel_id, None)
            self._failures.pop(channel_id, None)
            return True

    def record_success(self, channel_id):
        """Clears any failure streak/cooldown -- one working request is
        enough to trust the channel again."""
        with self._lock:
            self._failures.pop(channel_id, None)
            self._cooldown_until.pop(channel_id, None)

    def record_failure(self, channel_id):
        """Counts one more consecutive failure; the `failure_threshold`-th
        one starts a fresh `cooldown_seconds` timeout from now. Returns
        True exactly when THIS call started that cooldown, so the caller
        can log the one line that explains why the channel goes quiet."""
        with self._lock:
            count = self._failures.get(channel_id, 0) + 1
            self._failures[channel_id] = count
            if count >= self._threshold:
                self._cooldown_until[channel_id] = self._clock() + self._cooldown
                return count == self._threshold
            return False


#: Origins Stremio's own web client runs from -- the only cross-origin
#: browser callers this bridge needs to support. `cors_allow_origin()`
#: returns `None` for anything else so `_send_json()` sends no
#: `Access-Control-Allow-Origin` header at all for an unrecognized
#: origin: this bridge binds to `127.0.0.1`, but that only limits which
#: machines can reach it, not which page loaded in the user's browser
#: can -- a wildcard `*` would let ANY site the user has open read back
#: this response's `behaviorHints.proxyHeaders.request` (cookies/
#: referer/user-agent for a known stream id) via `fetch()` (CWE-942).
#: Non-browser callers (Stremio desktop, curl, ...) send no `Origin`
#: header at all and are unaffected either way -- CORS is a browser-only
#: restriction on reading the response, not on the server accepting it.
ALLOWED_ORIGINS = frozenset((
    "https://app.strem.io",
    "https://web.strem.io",
    "https://staging.strem.io",
))


def cors_allow_origin(origin, allowed_origins=ALLOWED_ORIGINS):
    """The `Access-Control-Allow-Origin` header value to send back for a
    request's `Origin` header, or `None` to send no such header at all
    (see `ALLOWED_ORIGINS`)."""
    return origin if origin in allowed_origins else None


def collect_with_budget(
    pool, tasks, budget, on_error=None, on_late_complete=None, late_timeout=60.0,
):
    """Run every zero-arg callable in `tasks` (a `{key: callable}`
    mapping) on `pool` (a `concurrent.futures.Executor` the CALLER
    created and is responsible for disposing of -- typically via
    `pool.shutdown(wait=False)`, since Python 3.8 has no
    `shutdown(cancel_futures=True)` to cancel still-running work
    outright), collecting every non-empty result list into one flat
    list. Returns `(results, timed_out)`.

    Stops and returns whatever has completed so far, WITHOUT waiting for
    any task still running, the moment `budget` expires -- whether that
    is noticed via `as_completed()`'s own `timeout=` raising
    `concurrent.futures.TimeoutError`, or via the `budget.expired()`
    check after each completion (belt-and-suspenders: the latter alone
    would still block on `as_completed()`'s internal wait for the next
    completion past the deadline if the former did not exist). Neither
    the timeout NOR any individual task raising is allowed to propagate:
    a stalled or broken task must degrade this request to partial
    results, never to an error response.

    `on_error(key, exc)`, if given, is called for a task whose callable
    raised -- the exception itself is always swallowed.
    `on_late_complete(all_results)`, if given, is called from a background
    daemon thread once EVERY task has finished (or `late_timeout` seconds
    pass), but only when the budget ran out first. It receives every
    task's results, not just the ones returned in time, so the caller can
    cache the complete answer for the next identical request: slow
    pipelines (a series needs search, episodes, sources and resolving)
    rarely fit one request budget, but they do finish shortly after.
    """
    results = []
    if not tasks:
        return results, False
    futures = {pool.submit(fn): key for key, fn in tasks.items()}

    def _value_of(future):
        try:
            return future.result() or []
        except Exception as exc:  # noqa: BLE001 - one task's failure must never drop the others
            if on_error is not None:
                on_error(futures[future], exc)
            return []

    def _timed_out():
        if on_late_complete is not None:
            threading.Thread(target=_finish_late, daemon=True).start()
        return results, True

    def _finish_late():
        done, _pending = _futures_wait(list(futures), timeout=late_timeout)
        all_results = []
        for future in futures:
            if future in done:
                # Error callbacks already fired for tasks seen in time;
                # a late failure is simply an empty contribution here.
                try:
                    all_results.extend(future.result() or [])
                except Exception:  # noqa: BLE001 - see above
                    pass
        try:
            on_late_complete(all_results)
        except Exception:  # noqa: BLE001 - a caching callback must never kill the thread noisily
            pass

    try:
        for future in as_completed(futures, timeout=max(budget.remaining(), 0.0)):
            value = _value_of(future)
            if value:
                results.extend(value)
            if budget.expired():
                return _timed_out()
        return results, False
    except _FuturesTimeoutError:
        return _timed_out()
