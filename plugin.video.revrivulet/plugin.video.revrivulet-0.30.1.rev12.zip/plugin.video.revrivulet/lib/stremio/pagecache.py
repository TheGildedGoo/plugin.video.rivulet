# SPDX-FileCopyrightText: 2026 M0Rf30
# SPDX-License-Identifier: MIT

"""Slim stale-while-revalidate cache for one catalog page.

This is not ``metacache.py``. That file refuses catalog bodies on
purpose; a shelf page lives here, in its own JSON file, with its own
byte budget. Only the fields a poster row, the hero panel and a decade sort
need are kept. Cast, trailers, links and awards are dropped before
the write.

Fresh for ``cacheMaxAge`` when the envelope sent one, otherwise 15
minutes. After that the page is still served, and the caller
revalidates, for ``staleRevalidate`` (default one hour). A failed
revalidate keeps serving it for a further ``staleError`` (default one
hour). Past that the lookup is a miss.

One ``save`` writes the whole file. Callers store a page when they
fetch it, not on every remote click.
"""

import json
import os
import tempfile
import threading
import time

#: About half a megabyte. Oldest pages go first. A single page that is
#: itself over the budget is kept: evicting it would make the cache
#: refuse the only page the screen needs.
BUDGET_BYTES = 512 * 1024

DEFAULT_MAX_AGE = 15 * 60
DEFAULT_STALE_REVALIDATE = 3600
DEFAULT_STALE_ERROR = 3600

_DESCRIPTION_LIMIT = 280

_SLIM_FIELDS = (
    'id', 'type', 'name', 'poster', 'background', 'logo',
    'year', 'releaseInfo', 'released', 'runtime', 'imdbRating', 'popularity',
    'genres',
    'rottenTomatoes', 'rtRating', 'tomatoMeter', 'tomatoes',
    'metascore', 'metacritic', 'metaScore',
)

#: Words that identify a score the hero panel can print. Anything else
#: in a `ratings` blob (Trakt, awards) is dropped with the rest of the
#: meta. "rt" is matched whole so it does not keep "runtime".
_RATING_NEEDLES = ('imdb', 'internet movie', 'rotten', 'tomato', 'metacritic', 'metascore')


def _keep_rating(source):
    low = str(source or '').lower().strip()
    if low == 'rt':
        return True
    return any(needle in low for needle in _RATING_NEEDLES)


def _slim_ratings(ratings):
    """The scores the hero panel prints, or None when there are none."""
    if isinstance(ratings, dict):
        kept = {}
        for key, value in ratings.items():
            if _keep_rating(key):
                kept[key] = value
        return kept or None
    if isinstance(ratings, list):
        kept = []
        for entry in ratings:
            if not isinstance(entry, dict):
                continue
            source = entry.get('source') or entry.get('name') or ''
            if not _keep_rating(source):
                continue
            value = entry.get('value') if 'value' in entry else entry.get('rating')
            kept.append({'source': source, 'value': value})
            if len(kept) == 6:
                break
        return kept or None
    return None


def slim_meta(meta):
    """The poster-row slice of one meta, or None when ``meta`` is not a dict."""
    if not isinstance(meta, dict):
        return None
    slim = {}
    for field in _SLIM_FIELDS:
        value = meta.get(field)
        if value is not None:
            slim[field] = value
    ratings = _slim_ratings(meta.get('ratings'))
    if ratings is not None:
        slim['ratings'] = ratings
    description = meta.get('description')
    if isinstance(description, str) and description:
        slim['description'] = description[:_DESCRIPTION_LIMIT]
    popularities = meta.get('popularities')
    if isinstance(popularities, dict) and 'moviedb' in popularities:
        slim['popularities'] = {'moviedb': popularities.get('moviedb')}
    return slim


def hints_from_envelope(envelope):
    """``cacheMaxAge`` / ``staleRevalidate`` / ``staleError`` / ``hasMore``.

    Non-numeric hints are ignored. ``hasMore`` is kept only as a bool,
    which is how the addon protocol sends it.
    """
    hints = {}
    if not isinstance(envelope, dict):
        return hints
    for name in ('cacheMaxAge', 'staleRevalidate', 'staleError'):
        value = envelope.get(name)
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            continue
        if value < 0:
            continue
        hints[name] = int(value)
    has_more = envelope.get('hasMore')
    if isinstance(has_more, bool):
        hints['hasMore'] = has_more
    return hints


def cache_key(transport, ctype, cid, extra=None):
    """Stable key: transport, type, catalog id, extra pairs in name order."""
    pairs = []
    for item in extra or []:
        if isinstance(item, (list, tuple)) and len(item) == 2:
            pairs.append((str(item[0]), str(item[1])))
    pairs.sort()
    encoded = '|'.join('%s=%s' % pair for pair in pairs)
    return '%s\n%s\n%s\n%s' % (transport or '', ctype or '', cid or '', encoded)


def _atomic_write(path, payload):
    directory = os.path.dirname(path) or '.'
    fd, tmp_path = tempfile.mkstemp(prefix='.tmp-pages-', dir=directory)
    try:
        with os.fdopen(fd, 'w') as handle:
            handle.write(json.dumps(payload, separators=(',', ':')))
        os.replace(tmp_path, path)
    except Exception:
        try:
            os.remove(tmp_path)
        except OSError:
            pass
        raise


class PageCache:
    """In-memory pages plus one JSON file. ``clock`` is injectable."""

    def __init__(self, path, clock=None):
        self.path = path
        self._clock = clock or time.time
        self._lock = threading.Lock()
        self._entries = {}
        self._load()

    def _now(self):
        return self._clock()

    def _load(self):
        try:
            with open(self.path) as handle:
                payload = json.load(handle)
        except (OSError, ValueError):
            return
        entries = payload.get('entries') if isinstance(payload, dict) else None
        if isinstance(entries, dict):
            self._entries = entries

    def lookup(self, key, now=None):
        """``('fresh'|'stale'|'miss', metas or None)``."""
        moment = self._now() if now is None else now
        with self._lock:
            entry = self._entries.get(key)
            if not isinstance(entry, dict):
                return 'miss', None
            stored = entry.get('stored_at')
            metas = entry.get('metas')
            if not isinstance(stored, (int, float)) or not isinstance(metas, list):
                return 'miss', None
            age = moment - stored
            fresh_for = entry.get('max_age', DEFAULT_MAX_AGE)
            revalidate_for = entry.get('stale_revalidate', DEFAULT_STALE_REVALIDATE)
            error_for = entry.get('stale_error', DEFAULT_STALE_ERROR)
            if age < fresh_for:
                return 'fresh', metas
            if age < fresh_for + revalidate_for + error_for:
                return 'stale', metas
            return 'miss', None

    def store(self, key, metas, hints=None, now=None):
        """Remember a slim copy of ``metas``. Does not write the file."""
        moment = self._now() if now is None else now
        hints = hints or {}
        slim = []
        for meta in metas or []:
            item = slim_meta(meta)
            if item is not None:
                slim.append(item)
        entry = {
            'stored_at': moment,
            'max_age': hints.get('cacheMaxAge', DEFAULT_MAX_AGE),
            'stale_revalidate': hints.get('staleRevalidate', DEFAULT_STALE_REVALIDATE),
            'stale_error': hints.get('staleError', DEFAULT_STALE_ERROR),
            'metas': slim,
        }
        with self._lock:
            self._entries[key] = entry
            self._evict()

    def _encoded_size(self):
        return len(json.dumps({'entries': self._entries}, separators=(',', ':')).encode('utf-8'))

    def _evict(self):
        """Drop the oldest entry until the payload fits, keeping at least one."""
        while len(self._entries) > 1 and self._encoded_size() > BUDGET_BYTES:
            oldest = min(self._entries, key=lambda key: self._entries[key].get('stored_at') or 0)
            del self._entries[oldest]

    def save(self):
        """One rewrite of the whole file."""
        with self._lock:
            payload = {'entries': self._entries}
        directory = os.path.dirname(self.path)
        if directory and not os.path.isdir(directory):
            os.makedirs(directory)
        _atomic_write(self.path, payload)
