# SPDX-FileCopyrightText: 2026 M0Rf30
# SPDX-License-Identifier: MIT

"""Kodi background service: supervises a local rivulet-engine process.

Launch interface verified against ~/rivulet-kodi/rivulet-engine @ cmd/rivulet-engine/main.go:
  - No CLI flags besides a `version`/`-version`/`--version` subcommand that just
    prints and exits (main.go:126-135) -- the daemon itself takes NO arguments.
  - All runtime config is via environment variables (main.go:141-181):
      APP_PATH   - data/cache root, default "~/.stremio-server" (main.go:141-144)
      HTTP_PORT  - enginefs HTTP API port, default 11470 (main.go:150)
    (APP_PATH and HTTP_PORT are pinned internally so the addon and the child
    process agree on where data lives and which port `server_url` points at;
    BIND_ADDRESS defaults to loopback whenever `server_url` is a loopback
    address, because the server is unauthenticated and otherwise listens on
    every interface -- see lib/serverenv.py; every other env var main.go
    reads is exposed as its own Kodi setting via
    EXTRA_ENV_SETTINGS/extra_env_from_settings below instead of being pinned.)
  - Logging goes to os.Stderr via internal/logging (logging.go:28-29), text or
    json per RIVULET_LOG_FORMAT/RIVULET_LOG_LEVEL -- there is no built-in log
    file, so this module captures the child's stdout+stderr into a file itself.
  - Shutdown is graceful: main.go:387-412 listens for os.Interrupt/SIGTERM and
    calls http.Server.Shutdown with a 5s timeout per listener. Popen.terminate()
    sends SIGTERM on POSIX, so a plain terminate()-then-wait(grace) drives the
    same path; kill() is only the fallback for a wedged process.

This module is split in two halves:
  - Pure process-management core (resolve_binary, probe_listening, ServerProcess,
    backoff helpers) -- no `xbmc*` imports anywhere at module scope, so it can be
    imported and unit-tested with plain python3.
  - main(), which does all `xbmc*` imports locally and drives an xbmc.Monitor
    loop on top of the pure core.
"""

import collections
import datetime
import os
import shutil
import subprocess
import threading
import time
from urllib.parse import urlparse

from lib import library, procflags, s4me, serverenv
from lib import settings as _settings
from lib.store import Store
from lib.stremio.api import StremioAPI

ADDON_ID = "plugin.video.rivulet"
DEFAULT_SERVER_URL = "http://127.0.0.1:11470"
DEFAULT_HTTP_PORT = 11470

BINARY_NAME = "rivulet-engine"
PROBE_PATHS = ("/settings", "/stats.json")
PROBE_TIMEOUT = 2.0

# Restart backoff schedule for a crashing child: 5s, 10s, 30s, then capped at 30s.
RESTART_BACKOFF = (5, 10, 30)

# Backoff schedule for a failing binary download attempt: retry after
# 30s, 60s, then every 5 minutes -- recovers automatically from a
# transient network/GitHub hiccup without hammering GitHub's API.
DOWNLOAD_RETRY_BACKOFF = (30, 60, 300)

#: Minimum interval between datastorePut pushes for one continuously-
#: playing session -- matches stremio-core's own player model
#: (`PUSH_TO_LIBRARY_EVERY`, src/models/player.rs:47), reused here
#: rather than inventing a different cadence.
LIBRARY_PUSH_INTERVAL_SECONDS = 90
#: Minimum interval between local `progress.json` writes for one
#: continuously-playing session -- far shorter than
#: `LIBRARY_PUSH_INTERVAL_SECONDS` (the remote push is rate-limited
#: separately), but well above `HEALTHY_POLL_INTERVAL` so a long
#: playback does not rewrite the whole cache file on every ~2s poll.
LOCAL_PROGRESS_WRITE_INTERVAL_SECONDS = 15
#: Interval between pulls of the account's watch state into
#: `progress.json` (see `ProgressPuller`). Each pull after the first is a
#: single `datastoreMeta` call (ids + mtimes only) plus a `datastoreGet`
#: for just the records that changed, so this mostly bounds how long a
#: title watched in another Stremio client takes to show up here.
LIBRARY_PULL_INTERVAL_SECONDS = 15 * 60
#: Ids per incremental `datastoreGet` -- keeps one request body bounded
#: when many records changed between two pulls.
LIBRARY_PULL_BATCH = 100
# A run shorter than this does not count as "stable" -- backoff keeps climbing
# instead of resetting, so a crash loop is actually throttled.
MIN_STABLE_UPTIME = 60.0

LOG_FILENAME = "server.log"
LOG_ROTATE_BYTES = 5 * 1024 * 1024
# main()'s HEALTHY branch calls ServerProcess.maybe_rotate_log() every tick
# (HEALTHY_POLL_INTERVAL, 2s), but a live child's log is only ever worth
# re-checking this coarsely: start()'s own _rotate_log() already handles the
# common case (rotate right before spawning), so the periodic check exists
# only to bound growth across a crash-free multi-day session -- a real risk
# on a near-full SD/eMMC box with a chatty rivulet-engine binary. Gating the
# stat() to once per this many seconds keeps the idle-loop no-disk-touch
# property intact for every tick except one: 288 stats/day instead of 43200
# (one per 2s tick) for the exact same detection latency that matters here.
LOG_ROTATE_CHECK_INTERVAL = 300.0

# Default `ServerProcess.stop()` grace. rivulet-engine answers SIGTERM by
# draining its HTTP/HTTPS listeners for up to 5s (`shutOne` in
# internal/app/app.go) and only THEN closing the torrent client, so whenever a
# connection is still open - a stream being played or pre-buffered, the
# keep-alive pin - it exits ~5.02s after the signal (measured, 3/3 runs; an
# idle server exits in ~3ms). The old 5.0s grace expired inside that window and
# SIGKILLed the server just before its engine/bolt state was closed. Leave
# generous headroom over the drain (upstream's systemd unit allows 20s).
STOP_GRACE_SECONDS = 10.0

IDLE_POLL_INTERVAL = 2.0
HEALTHY_POLL_INTERVAL = 2.0
EXTERNAL_RECHECK_INTERVAL = 10.0
MISSING_BINARY_RECHECK_INTERVAL = 5.0
# After an auto-download completes, recheck almost immediately so the
# freshly-installed binary is picked up on the very next loop iteration
# instead of waiting out a full missing-binary recheck cycle.
POST_DOWNLOAD_RECHECK_INTERVAL = 0.5

# Once install_binary() raises UnsupportedPlatformError, `unsupported_platform`
# latches True for the rest of the session (see main()'s ServiceMonitor loop,
# next to that flag's declaration, for the latch invariant). On Android that
# exception now comes exclusively from verify_executable() re-raising an
# OSError out of the exec attempt -- Android's own pre-network refusal is
# gone; install_binary() always downloads there now and lets the real exec
# attempt decide (see UnsupportedPlatformError's docstring). That single
# exception still cannot tell apart the two things that can cause it there:
# an SELinux-*enforcing* device's SDK>=29 W^X denial, a genuinely
# permanent-for-the-session platform property, from install_dir() having
# found no writable app-private /data candidate and fallen back to the
# noexec-mounted profile dir -- an environment condition that, while
# unlikely to change mid-session, is not architecturally guaranteed
# permanent either. So the latch must NOT disable detection: a latched
# iteration keeps calling both
# probe_listening() (an external/manually-started server appearing at
# server_url, the "only remedy" UnsupportedPlatformError's own docstring
# points users at) and resolve_binary() (a binary appearing, or the
# transient cause clearing -- when nothing was installed yet, install_binary()
# deliberately leaves the chmod'd binary at the exact bundled path
# resolve_binary() checks even though verify_executable() rejected it, so a
# now-runnable executable can already be sitting there when this exception
# fires; it does NOT do that when it would have to overwrite a binary that
# was already installed). What the latch does is coarsen the recheck
# cadence from MISSING_BINARY_RECHECK_INTERVAL's 5s to this interval instead
# -- still frequent enough to notice either kind of recovery within 5
# minutes, far short of the 17,280 wakeups/day the old un-coarsened 5s
# cadence would cost re-running the same stat/access + PATH scan on every
# Android TV box where `server_enable` defaults on and the embedded server
# can never run there. resolve_binary() finding a binary while latched
# clears the latch immediately (see the branch below); if install work is
# ever retried at that point and the cause actually was the permanent
# SELinux-enforcing one, it just re-latches -- misclassifying the transient
# cause only costs a 5s -> 300s slower rediscovery, never a stuck session.
# Deliberately coarser than EXTERNAL_RECHECK_INTERVAL since finding nothing
# via either check is the common, unremarkable case while latched.
UNSUPPORTED_PLATFORM_POLL_INTERVAL = 300.0

# --- startup autoload -------------------------------------------------------
#
# With `startup_autoload` on, the service opens Rivulet's own UI once per
# Kodi session, so a dedicated media box boots straight into the addon
# instead of Kodi's home screen.
#
# `RunAddon(plugin.video.rivulet)` is the builtin to use, NOT
# `ActivateWindow(Videos, plugin://...)`: a bare invocation of this addon
# opens the custom HomeWindow (see default.py), which is a modal
# WindowXMLDialog rather than a directory listing, and RunAddon is the
# standard "launch this addon as the user would" entry point. The user can
# still back out of it to Kodi's home screen normally.
AUTOLOAD_BUILTIN = "RunAddon(%s)" % ADDON_ID

# Kodi starts add-on services well before the GUI has finished coming up;
# firing the builtin into a skin that is still loading has been observed to
# do nothing at all (the window opens behind the splash, or the command is
# dropped). Wait for Kodi to report the home window as ready, then wait a
# further settling delay before launching.
AUTOLOAD_READY_POLL_INTERVAL = 1.0
AUTOLOAD_SETTLE_DELAY = 5.0
# Give up waiting for a "ready" GUI after this long and launch anyway --
# an unusual skin that never reports ready must not silently disable the
# feature for the whole session.
AUTOLOAD_READY_TIMEOUT = 60.0

# Every env var rivulet-engine's main() reads besides APP_PATH/HTTP_PORT
# (which stay pinned in ServerProcess.build_env()), one row per Kodi setting:
# (kodi_setting_id, env_var, kind). `kind` drives both how ServiceMonitor
# (inside main() below) reads the raw Kodi setting value and how
# extra_env_from_settings() turns it into an env var string:
#   'string'      - forwarded only when truthy (matches main.go treating ""
#                   as "use the binary's own default").
#   'int'         - always forwarded as str(value); the Kodi default equals
#                   the binary's own default, so an untouched setting is a
#                   no-op.
#   'mb_to_bytes' - Kodi setting stores MB; always forwarded as
#                   str(value * 1024 * 1024).
#   'bool'        - always forwarded as 'true'/'false'.
EXTRA_ENV_SETTINGS = (
    ("bt_listen_port", "BT_LISTEN_PORT", "int"),
    ("peers_per_torrent", "RIVULET_PEERS_PER_TORRENT", "int"),
    ("torrent_idle_timeout", "RIVULET_TORRENT_IDLE_TIMEOUT", "int"),
    ("bt_encryption", "RIVULET_BT_ENCRYPTION", "string"),
    ("bt_anonymous", "RIVULET_BT_ANONYMOUS", "bool"),
    ("disable_trackers", "RIVULET_DISABLE_TRACKERS", "bool"),
    ("bt_proxy", "RIVULET_BT_PROXY", "string"),
    ("disable_webtorrent", "RIVULET_DISABLE_WEBTORRENT", "bool"),
    ("trackers_max", "RIVULET_TRACKERS_MAX", "int"),
    ("trackers_url", "RIVULET_TRACKERS_URL", "string"),
    ("dht_bootstrap", "RIVULET_DHT_BOOTSTRAP", "string"),
    ("memory_cache_size_mb", "RIVULET_MEMORY_CACHE_SIZE", "mb_to_bytes"),
    ("mem_limit_mb", "RIVULET_MEM_LIMIT", "mb_to_bytes"),
    ("proxy_prebuffer", "RIVULET_PROXY_PREBUFFER", "int"),
    ("proxy_seg_cache_ttl", "RIVULET_PROXY_SEG_CACHE_TTL", "int"),
    ("proxy_password", "RIVULET_PROXY_PASSWORD", "string"),
    ("proxy_ip_acl", "RIVULET_PROXY_IP_ACL", "string"),
    ("proxy_public_url", "RIVULET_PROXY_PUBLIC_URL", "string"),
    ("proxy_upstream", "RIVULET_PROXY_UPSTREAM", "string"),
    ("proxy_secret", "RIVULET_PROXY_SECRET", "string"),
    ("enable_dlna", "RIVULET_ENABLE_DLNA", "bool"),
    ("local_imdb", "RIVULET_LOCAL_IMDB", "bool"),
    ("metadata_url", "RIVULET_METADATA_URL", "string"),
    ("bitmagnet_url", "RIVULET_BITMAGNET_URL", "string"),
    ("torznab_url", "RIVULET_TORZNAB_URL", "string"),
    ("torznab_apikey", "RIVULET_TORZNAB_APIKEY", "string"),
    ("web_ui_location", "WEB_UI_LOCATION", "string"),
    ("https_port", "HTTPS_PORT", "int"),
    ("pprof_addr", "RIVULET_PPROF", "string"),
    ("cert_authkey", "RIVULET_CERT_AUTHKEY", "string"),
)

#: settings.xml's <default> for `server_enable` plus every EXTRA_ENV_SETTINGS
#: row of kind "bool"/"int"/"mb_to_bytes" -- the fallback ServiceMonitor._refresh()
#: passes to lib.settings.setting_bool()/setting_int() so an untouched setting
#: resolves to the same value the old getSettingBool()/getSettingInt() calls
#: produced, string-kind rows need no typed default (read raw via getSetting()).
EXTRA_ENV_TYPED_DEFAULTS = {
    "server_enable": True,
    "bt_listen_port": 0,
    "peers_per_torrent": 0,
    "torrent_idle_timeout": 300,
    "bt_anonymous": False,
    "disable_trackers": False,
    "disable_webtorrent": True,
    "trackers_max": 5,
    "memory_cache_size_mb": 0,
    "mem_limit_mb": 0,
    "proxy_prebuffer": 3,
    "proxy_seg_cache_ttl": 300,
    "enable_dlna": False,
    "local_imdb": True,
    "https_port": 12470,
}


def extra_env_from_settings(values):
    """Turn a `{kodi_setting_id: raw_value}` dict into the `{env_var: str}`
    overlay `ServerProcess.build_env()` applies, per EXTRA_ENV_SETTINGS's
    `kind` semantics. A `kodi_setting_id` missing from `values` is treated
    as if the setting were absent -- its row is skipped, never a KeyError.
    """
    env = {}
    for setting_id, env_var, kind in EXTRA_ENV_SETTINGS:
        if setting_id not in values:
            continue
        value = values[setting_id]
        if kind == "string":
            if value:
                env[env_var] = str(value)
        elif kind == "int":
            env[env_var] = str(value)
        elif kind == "mb_to_bytes":
            env[env_var] = str(value * 1024 * 1024)
        elif kind == "bool":
            env[env_var] = "true" if value else "false"
    return env


def http_port_from_url(server_url, default=DEFAULT_HTTP_PORT):
    """Extract the TCP port `server_url` points at, falling back to `default`."""
    try:
        port = urlparse(server_url).port
    except (ValueError, AttributeError):
        return default
    return port if port is not None else default


def server_url_for_log(server_url):
    """`scheme://host[:port]` of `server_url` for the service log: the
    credentials/path/query a free-text `server_url` may carry (it is
    documented as the way to reach an arbitrary external instance) never
    reach kodi.log."""
    try:
        parsed = urlparse(server_url)
        host = parsed.hostname or ""
        port = parsed.port
    except (ValueError, AttributeError):
        return "<invalid server_url>"
    if ":" in host:  # IPv6 literal: urlparse strips the brackets
        host = "[%s]" % host
    return "%s://%s%s" % (parsed.scheme, host, (":%d" % port) if port is not None else "")


def _bundled_bin_dirs(addon_data_dir):
    """Yield, in order and de-duplicated, the directories resolve_binary()/
    is_bundled_binary() must treat as "ours": serverbin.install_dir()'s pick
    for the current environment first -- the Android app-private location
    when applicable, or the plain `<addon_data_dir>/bin` everywhere else --
    then the plain `<addon_data_dir>/bin` every platform used before
    Android support existed (an exact no-op on every non-Android platform,
    where both are the same directory).

    install_dir() MUST come first: `_upgrade_bundled_if_stale()` stamps and
    re-installs into install_dir(), so a leftover pre-Android-support binary
    in the plain directory that won the lookup would shadow every later
    upgrade -- the fresh install would be used for one session, after which
    the stale, possibly non-executable legacy file would be spawned again
    while the stamp next to the new one kept saying "up to date".

    `lib.serverbin` is imported here although it costs its module-scope
    hashlib/tarfile/zipfile/subprocess imports: the already-installed case
    imports it anyway for the stale-tag check right after, and the paths
    that never need it (an external server answering, the embedded server
    disabled) return before reaching resolve_binary() at all.
    """
    from lib import serverbin

    preferred = serverbin.install_dir(addon_data_dir, ADDON_ID)
    yield preferred

    plain = os.path.join(addon_data_dir, "bin")
    if plain != preferred:
        yield plain


def resolve_binary(explicit_path, addon_data_dir):
    """Resolve the rivulet-engine binary path.

    Priority: explicit setting -> the bin dir serverbin.install_dir() targets
    for this addon_data_dir (the Android app-private dir where applicable,
    else <addon_data_dir>/bin) -> the legacy <addon_data_dir>/bin on Android
    (see _bundled_bin_dirs()) -> PATH lookup. Returns None when nothing
    usable is found.
    """
    if explicit_path and os.path.isfile(explicit_path) and os.access(explicit_path, os.X_OK):
        return explicit_path

    for bin_dir in _bundled_bin_dirs(addon_data_dir):
        bundled = os.path.join(bin_dir, BINARY_NAME)
        for candidate in (bundled, bundled + ".exe"):
            if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
                return candidate

    return shutil.which(BINARY_NAME)


def is_bundled_binary(path, addon_data_dir):
    """True if `path` is one of the binaries lib.serverbin.install_binary()
    manages for this addon_data_dir: `<addon_data_dir>/bin/rivulet-engine[.exe]`
    and, on Android, the app-private location serverbin.install_dir() would
    instead pick (see _bundled_bin_dirs()).

    An exact string comparison against the same candidates resolve_binary()
    builds, which is sound precisely because `path` is expected to have come
    from resolve_binary() -- so it is either one of those literals or
    something else entirely (the user's explicit `server_binary` setting, or
    a PATH hit). Neither of those is ours to replace, which is the whole
    point of asking.
    """
    for bin_dir in _bundled_bin_dirs(addon_data_dir):
        bundled = os.path.join(bin_dir, BINARY_NAME)
        if path in (bundled, bundled + ".exe"):
            return True
    return False


def probe_listening(server_url, timeout=PROBE_TIMEOUT):
    """Return True if something is already answering at server_url.

    Any completed HTTP exchange (including an HTTP error status) means a
    server is bound to that port -- only connection-level failures (refused,
    timed out, unresolvable) count as "nothing listening".

    `urllib.request`/`urllib.error` are imported here rather than at module
    scope: they pull in `http.client`, which unconditionally imports `ssl`
    + `email`, costing 10.7ms of this module's 18.3ms import time on
    desktop (an estimated 50-110ms during a Raspberry Pi boot storm), paid
    on every service startup even on iterations that never call this
    function (e.g. an embedded server already running healthily, or
    embedded mode disabled). Deferring the import to first call moves that
    cost off the module-import path without touching *what* gets probed:
    `server_url` is a free-text setting with no scheme/loopback constraint
    (settings.xml) and is documented as the way to point at "an
    already-reachable instance (external or manually-started)", including
    a TLS-fronted one -- so this goes through urllib.request (real
    scheme-default ports, TLS, the same broad exception handling as
    before) rather than a raw socket, which would silently mishandle
    https:// URLs, non-default ports, and non-ASCII hosts.
    """
    import socket
    import urllib.error
    import urllib.request

    base = server_url.rstrip("/")
    for path in PROBE_PATHS:
        try:
            with urllib.request.urlopen(base + path, timeout=timeout):
                pass
            return True
        except urllib.error.HTTPError as exc:
            # An HTTP error status still proves a server is listening. Close
            # the response HTTPError carries: leaking its socket raises
            # ResourceWarning, which the test suite promotes to a failure.
            exc.close()
            return True
        except (urllib.error.URLError, socket.timeout, ConnectionError, OSError,
                ValueError, UnicodeError):
            # Anything urlopen raises for "nothing reachable at this path":
            # refused/unresolvable/TLS-failed connections (URLError, whose
            # .reason is usually one of these OSErrors), a read timeout
            # (socket.timeout, a URLError subclass pre-3.10 but a bare
            # TimeoutError alias from 3.10+), and malformed input
            # (ValueError for an unsupported scheme, UnicodeError for a
            # non-ASCII host) -- server_url is free-text, so all of these
            # are expected user-input outcomes, not bugs. A bare `except
            # Exception` here would also swallow real programming errors
            # (AttributeError/TypeError) silently turning them into a
            # misleading "nothing listening".
            continue
    return False


class ServerProcess:
    """Owns the lifecycle of one rivulet-engine child process.

    Pure process management: no `xbmc*` imports, safe to unit test directly.
    """

    def __init__(self, binary, server_url, app_path, log_path, extra_env=None):
        self.binary = binary
        self.server_url = server_url
        self.app_path = app_path
        self.log_path = log_path
        self.extra_env = extra_env or {}
        self._proc = None
        self._log_fh = None
        self._started_at = None
        self._last_rotate_check = None

    @property
    def running(self):
        return self._proc is not None and self._proc.poll() is None

    def build_env(self):
        env = os.environ.copy()
        env["APP_PATH"] = self.app_path
        env["HTTP_PORT"] = str(http_port_from_url(self.server_url))
        # Before extra_env so an explicit BIND_ADDRESS setting still wins; see
        # lib.serverenv for why the default must be loopback, not "everywhere".
        env.update(serverenv.bind_address_overlay(self.server_url, self.extra_env, env))
        env.update(self.extra_env)
        return env

    def _rename_to_backup(self):
        """Rename `log_path` -> `log_path + ".1"`, replacing any existing
        backup. No size check here -- callers that already know the file
        is oversized (both `_rotate_log()` and `maybe_rotate_log()`) call
        this directly so the check itself is never duplicated."""
        try:
            backup = self.log_path + ".1"
            if os.path.exists(backup):
                os.remove(backup)
            os.rename(self.log_path, backup)
        except OSError:
            pass

    def _rotate_log(self):
        try:
            if os.path.getsize(self.log_path) > LOG_ROTATE_BYTES:
                self._rename_to_backup()
        except OSError:
            pass

    def start(self):
        if self.running:
            return
        os.makedirs(self.app_path, exist_ok=True)
        self._rotate_log()
        try:
            self._log_fh = open(self.log_path, "a", buffering=1)
            self._proc = subprocess.Popen(
                [self.binary],
                env=self.build_env(),
                stdout=self._log_fh,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                # Suppress Windows' console-window popup for this console-
                # subsystem child; see lib/procflags.py for why.
                **procflags.no_window_kwargs(),
            )
        except OSError:  # open()/Popen() failures are OSError (ENOENT, EACCES, ...); anything else is a real bug
            if self._log_fh is not None:
                self._log_fh.close()
            self._proc = None
            self._log_fh = None
            raise
        self._started_at = time.monotonic()
        self._last_rotate_check = self._started_at

    def _truncate_live_log(self):
        """Reset the log file `self._log_fh` is *currently* writing to back
        to zero bytes without disturbing the open fd. Called by
        `maybe_rotate_log()` once a live rotation has already happened this
        run (log_path renamed away, see its docstring) and the file the
        child is now appending to (`.1`) has grown past LOG_ROTATE_BYTES
        again -- there is no third name left to rotate `.1` into, and
        nothing recreates log_path until the next start(), so renaming
        again is not an option. open()'s "a" mode sets O_APPEND on the fd
        (POSIX): ftruncate() shrinking the file to zero does not race the
        writer, every subsequent write still lands at the new (zero) end
        of file. This loses the current file's history instead of
        renaming it aside -- an accepted tradeoff for bounding disk usage
        without restarting the child (see maybe_rotate_log()'s docstring).
        """
        if self._log_fh is None:
            return
        try:
            os.ftruncate(self._log_fh.fileno(), 0)
        except OSError:
            pass

    def maybe_rotate_log(self):
        """Periodic size check for a LIVE process's log, called by main()'s
        HEALTHY branch on every poll tick. Gated on LOG_ROTATE_CHECK_INTERVAL
        (a coarse monotonic timestamp, not a per-tick stat()): start()'s own
        `_rotate_log()` call only ever runs once, right before spawning, so
        without this a chatty binary's log grows unbounded across a crash-
        free multi-day session -- a real risk on a near-full SD/eMMC box.

        The child's stdout fd (`self._log_fh`, wired in start() via
        `Popen(stdout=self._log_fh)`) was opened against log_path's INODE,
        not its path -- `os.rename()` only relabels a path, it never
        touches an already-open fd. So the FIRST time this fires against
        an oversized live log, it rotates exactly like `_rotate_log()`
        (rename log_path -> `.1`): the child keeps appending to the same
        inode, now reachable only at `.1`, and log_path does not exist
        again until the next start() creates a fresh one.

        EVERY firing after that must therefore watch `.1`, not log_path
        (which stays missing for the rest of this run) -- and since there
        is no third name to rotate `.1` into, the only way left to cap its
        growth without restarting the child is to ftruncate the same open
        fd back to zero once `.1` itself crosses LOG_ROTATE_BYTES again
        (`_truncate_live_log()`). That loses the oldest lines of the
        current run rather than the whole file -- an accepted tradeoff: a
        bounded log that forgets its history beats an unbounded one
        filling up a near-full SD/eMMC box.

        Windows caveat: os.rename() of a file the child (and self._log_fh)
        holds open fails there with PermissionError (CPython never requests
        FILE_SHARE_DELETE, bpo-15244), which _rename_to_backup() swallows.
        So after attempting the rename, this re-checks whether log_path is
        actually gone and falls back to truncating the live fd -- the same
        bounded-but-history-losing tradeoff as the `.1` case, so the
        invariant below holds on every platform instead of silently
        degrading to unbounded growth on Windows.

        Net invariant, true at any point across an arbitrarily long
        healthy session: total on-disk log bytes (log_path plus `.1`)
        never exceed roughly 2x LOG_ROTATE_BYTES: the threshold itself
        plus at most one check interval's worth of growth before the next
        gate catches it.
        """
        now = time.monotonic()
        if self._last_rotate_check is not None and now - self._last_rotate_check < LOG_ROTATE_CHECK_INTERVAL:
            return
        self._last_rotate_check = now
        live_path = self.log_path if os.path.exists(self.log_path) else self.log_path + ".1"
        try:
            oversized = os.path.getsize(live_path) > LOG_ROTATE_BYTES
        except OSError:
            return
        if not oversized:
            return
        if live_path == self.log_path:
            self._rename_to_backup()
            if os.path.exists(self.log_path):
                # Rename failed (Windows: open file, WinError 32) --
                # bound growth anyway by resetting the live fd.
                self._truncate_live_log()
        else:
            self._truncate_live_log()

    def poll(self):
        """Return the exit code if the child has died, else None."""
        if self._proc is None:
            return None
        return self._proc.poll()

    def uptime(self):
        """Seconds since start(), or None if never started."""
        if self._started_at is None:
            return None
        return time.monotonic() - self._started_at

    def stop(self, grace=STOP_GRACE_SECONDS):
        """Terminate the child, escalating to kill() after `grace` seconds.

        Log-file cleanup always runs, in `finally`, even when the child
        cannot be confirmed dead. A second `TimeoutExpired` after kill()
        propagates instead of being swallowed, and `_proc`/`_started_at`
        are left untouched in that case: `running` keeps reporting True
        so a caller does not spawn a duplicate next to a possibly-still-
        alive, unkillable child -- only confirmed termination discards
        the process/start state."""
        proc = self._proc
        try:
            if proc is not None and proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=grace)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait(timeout=grace)
            elif proc is not None:
                proc.wait()
        finally:
            if self._log_fh is not None:
                self._log_fh.close()
                self._log_fh = None
        self._proc = None
        self._started_at = None


class _AbortRequested(Exception):
    """Raised by main()'s download-progress callback (passed to
    serverbin.install_binary()) so a multi-minute binary download unwinds
    the instant Kodi requests shutdown, instead of blocking
    monitor.abortRequested() from ever being re-polled until the transfer
    finishes on its own.
    """


class AutoloadTrigger:
    """One-shot "open Rivulet's UI once the GUI is up" decision, kept out
    of `main()`'s loop body so it can be unit-tested without Kodi.

    `main()` calls `poll(now)` once per supervision-loop iteration and
    gets back either `None` (nothing to do this iteration) or the number
    of seconds it should cap its own sleep at, so the launch is not
    delayed by a long idle interval. The trigger latches after firing:
    it launches at most once per Kodi session, no matter how many times
    `poll()` is called or how the setting changes afterwards.

    Both collaborators are plain callables so this stays Kodi-free:
      - `gui_ready_fn() -> bool`: is Kodi's GUI up? (`main()` passes an
        `xbmc.getCondVisibility('Window.IsVisible(home)')` probe.)
      - `launch_fn()`: actually run the builtin.
    `disabled` short-circuits everything -- the setting is read once, at
    construction, precisely because a mid-session toggle should take
    effect at the NEXT Kodi startup rather than popping the UI open over
    whatever the user is doing right now.
    """

    def __init__(
        self, gui_ready_fn, launch_fn, started_at, disabled=False,
        settle_delay=AUTOLOAD_SETTLE_DELAY, ready_timeout=AUTOLOAD_READY_TIMEOUT,
        poll_interval=AUTOLOAD_READY_POLL_INTERVAL,
    ):
        self._gui_ready = gui_ready_fn
        self._launch = launch_fn
        self._started_at = started_at
        self._settle_delay = settle_delay
        self._ready_timeout = ready_timeout
        self._poll_interval = poll_interval
        self.fired = disabled  # a disabled trigger is "already done"
        self._launch_at = None

    def poll(self, now):
        """Advance the state machine. Returns a suggested maximum sleep
        (seconds) for this loop iteration, or None when the trigger has
        nothing left to ask for."""
        if self.fired:
            return None

        if self._launch_at is None:
            waited = now - self._started_at
            if not self._gui_ready() and waited < self._ready_timeout:
                return self._poll_interval
            self._launch_at = now + self._settle_delay

        remaining = self._launch_at - now
        if remaining > 0:
            return min(remaining, self._poll_interval)

        self.fired = True
        self._launch()
        return None


def should_push_now(last_pushed_at, now, final, interval=LIBRARY_PUSH_INTERVAL_SECONDS):
    """True if a `datastorePut` push should happen now: always on the
    FINAL sample of a session (the last chance to sync before playback
    ends), the very first sample (`last_pushed_at is None`), or once
    `interval` seconds have passed since the last push. Keeps
    `build_progress_player`'s tracker from hammering the Stremio API on
    every `sample_if_playing()` tick.
    """
    if final or last_pushed_at is None:
        return True
    return (now - last_pushed_at).total_seconds() >= interval


#: Ceiling on how old a persisted now-playing context's `started_at`
#: may be before `_RivuletPlayer` treats it as still actionable. Bounds
#: the window between `lib.ui.player` writing the context (right
#: before handing the resolved stream to Kodi -- see its own docstring)
#: and this SAME player instance accepting it via `onAVStarted`, so a
#: crashed previous session's leftover context can never steer an
#: unrelated LATER video's resume seek or progress sample.
MAX_STARTUP_AGE_SECONDS = 60


def is_context_stale(started_at, now, max_age_seconds=MAX_STARTUP_AGE_SECONDS):
    """True if `started_at` (the ISO 8601 UTC string `library.iso8601_utc()`
    produces) is missing, malformed, or more than `max_age_seconds` older
    than `now` (both `datetime.datetime`). Pure and side-effect-free --
    callers decide what "stale" means for their own now-playing context."""
    if not started_at:
        return True
    try:
        parsed = datetime.datetime.strptime(started_at, "%Y-%m-%dT%H:%M:%SZ")
    except (TypeError, ValueError):
        return True
    parsed = parsed.replace(tzinfo=datetime.timezone.utc)
    return (now - parsed).total_seconds() > max_age_seconds


def _context_key(context):
    """Stable identity for a now-playing context dict -- lets
    `_RivuletPlayer.sample_if_playing` tell whether it is looking at the
    EXACT context `onAVStarted` already accepted for this instance."""
    return (context.get("type"), context.get("id"), context.get("video_id"), context.get("started_at"))


def build_progress_player(xbmc_module, store, api, log_fn, sync_enabled_fn, spawn_fn=None):  # noqa: C901 - legacy; ratchet
    """Return an `xbmc.Player` subclass instance reporting playback
    progress for Rivulet-originated playback only, and performing the
    one-shot resume seek `lib.ui.player` queues via
    `Store.set_resume_offset_ms`.

    `xbmc_module` is the `xbmc` package itself (the real one, or in
    tests the shared `tests/kodistubs` fake) -- taken as a PARAMETER
    rather than imported at this module's top so the whole module stays
    plain-python3 importable (see the module docstring's "pure core"
    split): only `main()` (and this factory, once it is actually
    called) ever needs a real or stubbed `xbmc.Player` to exist.

    Kodi invokes `onAVStarted`/`onPlayBackStopped`/`onPlayBackEnded` on
    every live `Player` instance for ANY playback in the whole Kodi
    session, not just this addon's -- hence every callback below first
    checks `store.get_now_playing()` and no-ops when no Rivulet context
    is active. `sample_if_playing()` is NOT a Kodi callback -- `main()`'s
    own poll loop calls it once per iteration, approximating
    "periodically while playing"; `xbmc.Player` has no native
    periodic-tick hook to drive that instead. Unlike the callbacks,
    `sample_if_playing()` checks `isPlayingVideo()` (a cheap native
    binding call) BEFORE `store.get_now_playing()` (a disk read), so an
    idle Kodi -- the common case for a background service -- never
    touches disk on this per-tick path at all.

    `sync_enabled_fn`/`log_fn` are plain callables (`sync_enabled_fn() ->
    bool`, `log_fn(level, message)`) rather than an `xbmcaddon.Addon`/
    `xbmc.log` reference directly, so this factory itself needs no
    xbmc-specific type beyond the `xbmc_module.Player` base class.

    The `datastoreGet`+`datastorePut` push to the Stremio API runs on a
    daemon worker (`spawn_fn`, default `_spawn_daemon`), one at a time,
    never on the caller: both calls carry the API's multi-second timeout,
    and the callers are `main()`'s supervision tick (health checks,
    restarts, the abort check) and Kodi's playback callbacks, none of
    which may stall behind a slow account server. `drain_pushes()` lets
    shutdown give a queued final push a bounded moment to finish.
    """

    spawn = spawn_fn or _spawn_push_worker

    class _RivuletPlayer(xbmc_module.Player):
        def __init__(self):
            super().__init__()
            self._last_pushed_at = None
            self._last_local_write_at = None
            self._accepted_key = None
            #: `(context_key, position_ms, duration_ms)` of the newest
            #: successful live read. Kodi's `xbmc.Player.getTime()` raises
            #: `RuntimeError("Kodi is not playing any media file")` once
            #: playback has stopped, and `onPlayBackStopped`/`Ended`/`Error`
            #: only fire AFTER that point (kodi.log: the exception lands
            #: ~0.1s after `CVideoPlayer::CloseFile()`), so the final flush can
            #: never read the player itself - it replays this instead.
            self._last_sample = None
            #: Pushes waiting for the single worker, oldest first. Guarded
            #: by `_push_lock`, as is `_push_running` (a worker is alive
            #: and will drain the list before it exits).
            self._push_jobs = []
            self._push_running = False
            self._push_lock = threading.Lock()
            self._push_idle = threading.Event()
            self._push_idle.set()

        def onAVStarted(self):
            context = store.get_now_playing()
            if context is None:
                return
            now = datetime.datetime.now(datetime.timezone.utc)
            if is_context_stale(context.get("started_at"), now):
                store.set_now_playing(None)
                store.set_resume_offset_ms(None)
                return
            self._accepted_key = _context_key(context)
            self._last_local_write_at = None
            self._last_sample = None
            offset_ms = store.get_resume_offset_ms()
            if not offset_ms:
                return
            store.set_resume_offset_ms(None)
            try:
                self.seekTime(offset_ms / library.MS_PER_SECOND)
            except Exception as exc:  # noqa: BLE001 - a seek failure must never crash the service or interrupt playback
                log_fn(xbmc_module.LOGWARNING, "resume seek failed: %r" % (exc,))

        def onPlayBackStopped(self):
            self._terminate()

        def onPlayBackEnded(self):
            self._terminate()

        def onPlayBackError(self):
            # Kodi calls this instead of (not necessarily followed by)
            # onPlayBackStopped/onPlayBackEnded when playback fails
            # outright (dead/expired link, unsupported codec, network
            # drop mid-attempt). Without this, a failed attempt's
            # context/resume offset would stay persisted for the next
            # unrelated video the long-lived Player instance sees start.
            self._terminate(failed=True)

        def _terminate(self, failed=False):
            # Shared terminal-callback cleanup. The final flush only
            # happens for a context this SAME instance already accepted
            # via onAVStarted (an error/stop firing before that point
            # must never persist/push a sample of playback that never
            # really started for Rivulet).
            #
            # The persisted now-playing context and resume offset are
            # cleared only when this callback is about THEM, i.e. when
            # the stored context is the one this instance accepted, or
            # when playback FAILED before anything was accepted (the
            # attempt the context was written for just died). Otherwise
            # the callback belongs to some other video: `lib.ui.player`
            # writes the new context BEFORE `Player.play()`, and `play()`
            # over a running video first stops that one, so its stop
            # callback can land between the write and the new item's
            # onAVStarted -- clearing there would strip the new playback
            # of its context and queued resume seek. A stale leftover is
            # still swept by the age check in onAVStarted/sample_if_playing.
            context = store.get_now_playing()
            accepted = context is not None and _context_key(context) == self._accepted_key
            if accepted:
                try:
                    self._flush(context, final=True)
                except Exception as exc:  # noqa: BLE001 - final flush is best-effort; cleanup below is unconditional
                    log_fn(xbmc_module.LOGWARNING, "final flush failed: %r" % (exc,))
            owns_context = accepted or (failed and self._accepted_key is None)
            self._accepted_key = None
            self._last_sample = None
            self._last_local_write_at = None
            if owns_context:
                store.set_now_playing(None)
                store.set_resume_offset_ms(None)

        def sample_if_playing(self):
            """Call once per `main()` loop tick -- a no-op unless BOTH
            Kodi is actually mid-playback AND a Rivulet now-playing
            context is active. `isPlayingVideo()` is checked FIRST since
            it is a cheap native binding call, cheaper than the
            `store.get_now_playing()` disk read below -- an idle Kodi
            (the overwhelming common case) returns here without ever
            touching disk. Only flushes a context this instance already
            accepted via onAVStarted (exact identity match) -- a
            different/not-yet-accepted context is left alone (waiting
            for onAVStarted) unless it is stale, in which case it is
            cleared instead of ever being sampled. One onAVStarted
            already accepted keeps sampling for as long as it keeps
            playing, however old `started_at` gets."""
            try:
                playing = self.isPlayingVideo()
            except Exception:  # noqa: BLE001 - isPlayingVideo() must never crash the service loop
                playing = False
            if not playing:
                return
            context = store.get_now_playing()
            if context is None:
                return
            if _context_key(context) != self._accepted_key:
                now = datetime.datetime.now(datetime.timezone.utc)
                if is_context_stale(context.get("started_at"), now):
                    store.set_now_playing(None)
                    store.set_resume_offset_ms(None)
                return
            self._flush(context, final=False)

        def _flush(self, context, final):
            """Persist one playback sample for `context`. Both call
            sites (`sample_if_playing`, `_terminate`) already read
            `context` via `store.get_now_playing()` themselves -- to
            check `_accepted_key` before ever calling here -- so this
            takes it as a parameter instead of re-reading it from disk a
            second time within the same tick/callback.

            The final flush runs from Kodi's stop/end/error callbacks, which
            fire only after the player has closed (see `_last_sample`), so
            it must NEVER call `getTime()`/`getTotalTime()`: they raise
            `RuntimeError`, and Kodi's Python layer logs every such raise as
            `EXCEPTION: Kodi is not playing any media file` (kodi.log
            01:08:00.137) even though this code catches it. It replays the
            last periodic sample for the same context instead - that is the
            expected path, not a failure, so a missing sample is only a debug
            line. A periodic (non-final) read that fails mid-playback is
            still a warning."""
            key = _context_key(context)
            if final:
                cached = self._last_sample if self._last_sample and self._last_sample[0] == key else None
                if cached is None:
                    log_fn(xbmc_module.LOGDEBUG, "no playback sample to flush at stop")
                    return
                _, position_ms, duration_ms = cached
            else:
                try:
                    position_ms = int(self.getTime() * library.MS_PER_SECOND)
                    duration_ms = int(self.getTotalTime() * library.MS_PER_SECOND)
                except Exception as exc:  # noqa: BLE001 - getTime()/getTotalTime() must never crash the service
                    log_fn(xbmc_module.LOGWARNING, "playback sample failed: %r" % (exc,))
                    return
                self._last_sample = (key, position_ms, duration_ms)
            if duration_ms <= 0:
                return
            now = datetime.datetime.now(datetime.timezone.utc)
            if should_push_now(self._last_local_write_at, now, final,
                                interval=LOCAL_PROGRESS_WRITE_INTERVAL_SECONDS):
                self._last_local_write_at = now
                store.set_progress(
                    context["type"], context["id"], context.get("video_id"),
                    position_ms, duration_ms, library.iso8601_utc(),
                )
            if not should_push_now(self._last_pushed_at, now, final):
                return
            self._last_pushed_at = now
            self._queue_push(context, position_ms, duration_ms, final)

        def _queue_push(self, context, position_ms, duration_ms, final):
            """Hand one push to the single worker thread; never blocks.

            A periodic push is dropped when anything is already queued or
            in flight -- the next one is 90s away and carries a newer
            position anyway. A final push is never dropped: it is the last
            word on that playback, and queuing it behind an in-flight push
            keeps the order the API sees correct."""
            job = (context, position_ms, duration_ms)
            with self._push_lock:
                if self._push_running:
                    if final or not self._push_jobs:
                        self._push_jobs.append(job)
                    return
                self._push_jobs.append(job)
                self._push_running = True
                self._push_idle.clear()
            try:
                spawn(self._push_worker)
            except Exception as exc:  # noqa: BLE001 - a thread that cannot start must not fail the caller; local progress is already saved
                with self._push_lock:
                    self._push_jobs.clear()
                    self._push_running = False
                    self._push_idle.set()
                log_fn(xbmc_module.LOGWARNING, "library push not started: %r" % (exc,))

        def _push_worker(self):
            while True:
                with self._push_lock:
                    if not self._push_jobs:
                        self._push_running = False
                        self._push_idle.set()
                        return
                    job = self._push_jobs.pop(0)
                try:
                    self._push(*job)
                except Exception as exc:  # noqa: BLE001 - one bad push must not strand the queued ones
                    log_fn(xbmc_module.LOGWARNING, "library push failed: %r" % (exc,))

        def drain_pushes(self, timeout):
            """Wait up to `timeout` seconds for queued/in-flight pushes to
            finish; True when none remain. Called once at shutdown so the
            final push of a playback that ended with Kodi does not die
            with the daemon thread."""
            return self._push_idle.wait(timeout)

        def _push(self, context, position_ms, duration_ms):
            """Best-effort `datastorePut`, run on the worker thread: only
            when logged in AND the 'sync_progress' setting is on. A failure
            here is logged and swallowed -- `_flush` above has already
            written the local progress cache regardless, so a Stremio API
            hiccup never costs the user their local resume position."""
            if not sync_enabled_fn():
                return
            auth = store.get_auth()
            if not auth or not auth.get("authKey"):
                return
            try:
                existing = api.datastore_get(auth["authKey"], ids=[context["id"]], all=False)
                base = existing[0] if existing else library.build_library_item({
                    "id": context["id"],
                    "type": context["type"],
                    "name": context.get("name", ""),
                    "poster": context.get("poster"),
                })
                merged = library.merge_playback(
                    base, position_ms, duration_ms, video_id=context.get("video_id"),
                )
                api.datastore_put(auth["authKey"], [merged])
            except Exception as exc:  # noqa: BLE001 - a Stremio API hiccup must never interrupt playback or crash the service
                log_fn(xbmc_module.LOGWARNING, "library push failed: %r" % (exc,))

    return _RivuletPlayer()


class ProgressPuller:
    """Pull the Stremio account's watch state into the local progress
    cache (issue #74) -- the reverse of `_RivuletPlayer._push`, so titles
    watched in an official Stremio client appear in Rivulet's Continue
    Watching/Next Up/Recently Watched bands, including on a fresh install.

    `poll()` runs once per supervision tick and does nothing unless a
    pull is due: right after a login (a new `authKey`), then every
    `LIBRARY_PULL_INTERVAL_SECONDS`. The first pull for an `authKey`
    downloads the whole datastore; later ones diff `datastoreMeta`'s
    mtimes against the previous pull and fetch only changed ids. Gated by
    the same 'sync_progress' setting as the push, skipped while something
    is playing (the push is what owns that title's state then), and
    best-effort: a failure is logged and retried on the next interval,
    never raised into the supervision loop. Merge precedence is
    `Store.merge_remote_progress`'s: newer `updated_at` wins.

    The pull itself runs on a daemon worker thread (`spawn_fn`), one at
    a time: it is several synchronous API calls with a 15s timeout each,
    and running them inline would stall `Supervisor.run()`'s health
    checks and its abort/shutdown handling for as long. `abort_fn` is
    checked between requests so a Kodi quit stops the pull at the next
    boundary, before anything is written.
    """

    def __init__(self, store, api, log_fn, levels, sync_enabled_fn, is_playing_fn,
                 abort_fn, clock=time.monotonic, spawn_fn=None):
        self._store = store
        self._api = api
        self._log = log_fn
        self._levels = levels
        self._sync_enabled = sync_enabled_fn
        self._is_playing = is_playing_fn
        self._abort = abort_fn
        self._clock = clock
        self._spawn = spawn_fn or _spawn_daemon
        self._worker = None
        self._auth_key = None
        self._mtimes = None
        self._next_at = 0.0

    def poll(self):
        try:
            if self._worker is not None and self._worker.is_alive():
                return
            if not self._sync_enabled():
                self._auth_key = None
                return
            auth = self._store.get_auth() or {}
            auth_key = auth.get("authKey")
            if not auth_key:
                self._auth_key = None
                return
            now = self._clock()
            if auth_key != self._auth_key:
                self._auth_key = auth_key
                self._mtimes = None
                self._next_at = 0.0
            if now < self._next_at:
                return
            if self._is_playing():
                return
            self._next_at = now + LIBRARY_PULL_INTERVAL_SECONDS
            self._worker = self._spawn(lambda: self._run(auth_key, self._mtimes))
        except Exception as exc:  # noqa: BLE001 - a Stremio API hiccup must never crash the service loop
            self._log(self._levels.warning, "library pull failed: %r" % (exc,))

    def _run(self, auth_key, known_mtimes):
        try:
            self._pull(auth_key, known_mtimes)
        except Exception as exc:  # noqa: BLE001 - worker thread: nothing above it to catch this
            self._log(self._levels.warning, "library pull failed: %r" % (exc,))

    def _pull(self, auth_key, known_mtimes):
        meta = self._api.datastore_meta(auth_key)
        mtimes = {}
        for entry in meta:
            if isinstance(entry, (list, tuple)) and len(entry) == 2 and isinstance(entry[0], str):
                mtimes[entry[0]] = entry[1]
        if known_mtimes is None:
            if self._abort():
                return
            items = self._api.datastore_get(auth_key, all=True)
        else:
            changed = [item_id for item_id, mtime in mtimes.items() if known_mtimes.get(item_id) != mtime]
            items = []
            for start in range(0, len(changed), LIBRARY_PULL_BATCH):
                if self._abort():
                    return
                items.extend(self._api.datastore_get(
                    auth_key, ids=changed[start:start + LIBRARY_PULL_BATCH], all=False,
                ))
        # A logout/re-login while this ran makes the result stale.
        if self._abort() or self._auth_key != auth_key:
            return
        entries = [e for e in (library.progress_from_library_item(i) for i in items) if e is not None]
        written = self._store.merge_remote_progress(entries) if entries else 0
        self._mtimes = mtimes
        self._log(self._levels.info, "library pull: %d records, %d progress entries updated" % (len(items), written))


def _spawn_daemon(target, name="rivulet-library-pull"):
    """Start `target` on a daemon thread and return the thread -- daemon so
    a request still in flight at Kodi quit never holds the interpreter."""
    thread = threading.Thread(target=target, name=name)
    thread.daemon = True
    thread.start()
    return thread


def _spawn_push_worker(target):
    return _spawn_daemon(target, name="rivulet-library-push")


#: Longest `Supervisor.shutdown()` waits for the progress player's push
#: worker: long enough for one API round trip on a healthy link, short
#: enough that a dead network cannot hold up Kodi's quit.
PUSH_DRAIN_SECONDS = 3.0

#: How many supervision ticks `main()` reuses its last
#: `_detect_italian_user()` answer for (about five minutes at the healthy
#: cadence).
ITALIAN_USER_RECHECK_TICKS = 150


def _detect_italian_user(xbmc):
    """Whether the Kodi user is Italian, per `s4me.is_italian_user()`:
    interface language, then the preferred audio language.

    Takes the `xbmc` module so it stays importable (and patchable) outside
    Kodi. Every Kodi call is guarded: a missing API or a malformed
    JSON-RPC reply must read as "not Italian", never raise, because this
    runs inside the supervision loop."""
    import json

    ui_language = None
    try:
        ui_language = xbmc.getLanguage(xbmc.ISO_639_1)
    except Exception:  # noqa: BLE001 - absent/older API -> treat as unknown
        pass
    audio_language = None
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "Settings.GetSettingValue",
            "params": {"setting": "locale.audiolanguage"},
        })))
        audio_language = (reply.get("result") or {}).get("value")
    except Exception:  # noqa: BLE001 - JSON-RPC unavailable/malformed -> unknown
        pass
    return s4me.is_italian_user(ui_language, audio_language)


LogLevels = collections.namedtuple("LogLevels", "info warning error")
LogLevels.__doc__ = "The three `xbmc.LOG*` levels the supervisor logs at."


class ServiceMonitor:
    """Settings snapshot for the supervision loop.

    Plain (no `xbmc` import at module scope); main() mixes it with
    `xbmc.Monitor` so Kodi delivers `onSettingsChanged()` to it. `addon`
    and `settings` are injected, so it can also be exercised directly.
    """

    def __init__(self, addon, settings=_settings):
        super().__init__()
        self._addon = addon
        self._settings = settings
        self.restart_requested = False
        self.enabled = False
        self.binary_setting = ""
        self.server_url = DEFAULT_SERVER_URL
        self.extra_settings = {}
        self.extra_env = {}
        self.force_library = False
        self._refresh()

    def _refresh(self):
        addon = self._addon
        cfg = self._settings
        self.enabled = cfg.setting_bool(addon, "server_enable", EXTRA_ENV_TYPED_DEFAULTS["server_enable"])
        self.binary_setting = addon.getSetting("server_binary")
        self.server_url = addon.getSetting("server_url") or DEFAULT_SERVER_URL
        self.force_library = cfg.setting_bool(addon, "server_force_library", False)
        values = {}
        for setting_id, _env_var, kind in EXTRA_ENV_SETTINGS:
            default = EXTRA_ENV_TYPED_DEFAULTS.get(setting_id)
            if kind == "bool":
                values[setting_id] = cfg.setting_bool(addon, setting_id, default)
            elif kind in ("int", "mb_to_bytes"):
                values[setting_id] = cfg.setting_int(addon, setting_id, default)
            else:
                values[setting_id] = addon.getSetting(setting_id)
        self.extra_settings = values
        self.extra_env = extra_env_from_settings(values)

    def _snapshot(self):
        return (
            self.enabled, self.binary_setting, self.server_url, self.force_library,
            tuple(sorted(self.extra_settings.items())),
        )

    def onSettingsChanged(self):
        prev = self._snapshot()
        self._refresh()
        if prev != self._snapshot():
            self.restart_requested = True


class LoopState:
    """Mutable per-session state threaded explicitly through
    `Supervisor.tick_progress_and_restart()`/`Supervisor.dispatch()`
    instead of `nonlocal` closures."""

    def __init__(self):
        self.proc = None
        self.backoff_idx = 0
        self.notified_missing = False
        # Coarse-cadence latch, NOT a "stop detecting" latch: once
        # install_binary() raises UnsupportedPlatformError, this stays True
        # and the nothing-of-ours-running branch polls at
        # UNSUPPORTED_PLATFORM_POLL_INTERVAL (300s) instead of
        # MISSING_BINARY_RECHECK_INTERVAL (5s) -- but it keeps calling BOTH
        # probe_listening() and resolve_binary() every latched iteration
        # (see UNSUPPORTED_PLATFORM_POLL_INTERVAL's comment for why the
        # exception cannot tell a permanent cause from a transient one),
        # only skipping the install/download attempt itself. It clears
        # either when resolve_binary() finds a runnable binary while latched
        # (self-heal) or via onSettingsChanged() -> restart_requested.
        self.unsupported_platform = False
        self.download_backoff_idx = 0
        self.next_download_at = None
        self.download_attempt_notified = False
        self.download_failure_notified = False
        # One-shot per session: see Supervisor._upgrade_bundled_if_stale().
        # Deliberately NOT reset by onSettingsChanged() -- a settings change
        # is not new information about the release tag, and re-arming it
        # there would let a user toggling settings during a GitHub outage
        # re-download on every toggle.
        self.upgrade_attempted = False
        # Which kind of server this session is using, so the "not our
        # server" note is logged once per change, not once per tick:
        # None (unknown yet), "embedded", "external" or "disabled".
        self.server_mode = None

    def reset_download(self):
        self.download_backoff_idx = 0
        self.next_download_at = None
        self.download_attempt_notified = False
        self.download_failure_notified = False


class Supervisor:
    """The xbmc.Monitor-driven supervision loop of the embedded server.

    Every Kodi-facing dependency is injected, so the whole state machine
    runs under plain python:

    - `monitor`: `ServiceMonitor` mixed with `xbmc.Monitor` (settings
      snapshot + abortRequested()/waitForAbort()).
    - `log_fn(level, message)` / `levels`: a `LogLevels` of the xbmc levels.
    - `notify_fn(string_id, error=False)`: toast with a localized string.
    - `progress_player`: has `sample_if_playing()`.
    - `sync_bridge_fn()`, `shutdown_bridge_fn()`: S4Me bridge hooks.
    - `autoload`: an `AutoloadTrigger`.
    - `clock`: monotonic time source.

    Process/binary collaborators (ServerProcess, resolve_binary,
    probe_listening, ...) are resolved from this module at call time.
    """

    def __init__(
        self, monitor, profile_dir, log_fn, levels, notify_fn, progress_player,
        sync_bridge_fn, shutdown_bridge_fn, autoload, clock=None,
    ):
        self.monitor = monitor
        self.profile_dir = profile_dir
        self.app_path = os.path.join(profile_dir, "server")
        self.log_path = os.path.join(profile_dir, LOG_FILENAME)
        self._log_fn = log_fn
        self._levels = levels
        self._notify = notify_fn
        self.progress_player = progress_player
        self._sync_bridge = sync_bridge_fn
        self._shutdown_bridge = shutdown_bridge_fn
        self.autoload = autoload
        self._clock = clock or (lambda: time.monotonic())
        self.state = LoopState()

    # -- small helpers ----------------------------------------------------

    def _info(self, message):
        self._log_fn(self._levels.info, message)

    def _warn(self, message):
        self._log_fn(self._levels.warning, message)

    def _error(self, message):
        self._log_fn(self._levels.error, message)

    def _stop_process(self, target):
        """Best-effort `target.stop()`. Returns True once stop()
        completed (state is safe to discard), False if it raised (an
        unkillable/wedged child) -- callers must then keep polling the
        same instance next iteration instead of spawning a duplicate
        next to a possibly-still-alive process."""
        try:
            target.stop()
        except Exception as exc:  # noqa: BLE001 - a failed stop must never crash the supervision loop
            self._error(f"failed to stop embedded server: {exc}")
            return False
        return True

    @staticmethod
    def _backoff_interval(state):
        """Current restart interval, advancing `state.backoff_idx`."""
        interval = RESTART_BACKOFF[min(state.backoff_idx, len(RESTART_BACKOFF) - 1)]
        state.backoff_idx = min(state.backoff_idx + 1, len(RESTART_BACKOFF) - 1)
        return interval

    def _start_embedded_server(self, binary, state):
        """Spawn `binary` as the embedded server. Returns `(new_proc,
        new_interval)`: `(candidate, HEALTHY_POLL_INTERVAL)` on a
        successful start, or `(None, <backoff interval>)` on a failed
        spawn (advancing `state.backoff_idx`)."""
        self._info(f"starting embedded server: {binary}")
        candidate = ServerProcess(
            binary, self.monitor.server_url, self.app_path, self.log_path,
            extra_env=self.monitor.extra_env,
        )
        try:
            candidate.start()
        except Exception as exc:  # noqa: BLE001 - a failed spawn must never crash the supervision loop
            self._error(f"failed to start embedded server: {exc}")
            return None, self._backoff_interval(state)
        return candidate, HEALTHY_POLL_INTERVAL

    def _resolve_library_candidate(self):
        """Path of the librivulet-engine.so for c-shared library mode (see
        lib.libserver.LibraryServer), or None when unavailable: ctypes
        import failed in this Python build, or serverbin.install_binary()
        has not extracted a companion library yet. Cheap enough (an
        isfile() check) to call fresh wherever needed."""
        from lib import libserver
        if not libserver.LIBRARY_SUPPORTED:
            return None
        from lib import serverbin
        bin_dir = serverbin.install_dir(self.profile_dir, ADDON_ID)
        return serverbin.resolve_library(bin_dir)

    def _start_library_server(self, library_path, state):
        """Spawn the c-shared library server. Mirrors
        `_start_embedded_server()`'s `(candidate, interval)` contract and
        failed-spawn backoff, using lib.libserver.LibraryServer."""
        self._info(f"starting library-mode server: {library_path}")
        from lib import libserver

        candidate = libserver.LibraryServer(
            library_path, self.monitor.server_url, self.app_path, self.log_path,
            extra_env=self.monitor.extra_env,
            log_fn=lambda message: self._warn(message),
        )
        try:
            candidate.start()
        except Exception as exc:  # noqa: BLE001 - a failed spawn must never crash the supervision loop
            self._error(f"failed to start library-mode server: {exc}")
            return None, self._backoff_interval(state)
        return candidate, HEALTHY_POLL_INTERVAL

    def _start_library_with_exec_fallback(self, state, library_path):
        """Start library mode; if that fails, try an already-usable
        executable before giving up on this tick. A failed dlopen() must
        not unlatch `unsupported_platform` (it would re-enter the
        download path next tick), so the latch is re-armed iff nothing
        started. Returns the next interval."""
        state.proc, interval = self._start_library_server(library_path, state)
        if state.proc is None:
            binary = resolve_binary(self.monitor.binary_setting, self.profile_dir)
            if binary is not None:
                state.notified_missing = False
                state.proc, interval = self._start_embedded_server(binary, state)
        state.unsupported_platform = state.proc is None
        return interval

    def _abort_progress(self, done, total):
        """Download progress callback for serverbin.install_binary(): called
        once per chunk, so a multi-minute download notices a Kodi shutdown
        request within one chunk. Shared by the missing-binary install and
        `_upgrade_bundled_if_stale()`."""
        if self.monitor.abortRequested():
            raise _AbortRequested()

    def _abort_aware_sleep(self, seconds):
        """Backoff sleep between download retries for
        serverbin.install_binary(): waits on Kodi's abort instead of
        `time.sleep`, so a quit during a failing download unwinds at once
        rather than after the remaining backoff."""
        if self.monitor.waitForAbort(seconds):
            raise _AbortRequested()

    def _upgrade_bundled_if_stale(self, binary, state):
        """Reinstall `binary` when SERVER_TAG has moved past the tag it was
        installed from. Returns the path to use (the fresh one on success,
        `binary` unchanged otherwise).

        install_binary() only runs when resolve_binary() finds nothing, so
        without this a SERVER_TAG bump in a new addon release would never
        reach anyone who already has a binary installed.

        Three deliberate restrictions:
          - Bundled path only, and only when the user has not named it
            themselves (a PATH hit or a `server_binary` setting is the
            user's own build; `server_binary` can legitimately point AT
            the bundled path, so the setting is checked too).
          - Once per session (`state.upgrade_attempted`), so a failing
            download cannot re-fetch on every 5s spawn retry.
          - Failures are non-fatal: an offline user with a stale binary
            must still get their server started.

        _AbortRequested propagates -- Kodi is shutting down, and the
        caller unwinds the supervision loop instead of spawning.
        """
        if (state.upgrade_attempted
                or not is_bundled_binary(binary, self.profile_dir)
                or binary == self.monitor.binary_setting):
            return binary
        state.upgrade_attempted = True
        return self._reinstall_if_stale(binary)

    def _reinstall_if_stale(self, current):
        """Re-run `serverbin.install_binary()` into `install_dir()` when the
        tag stamp there is not SERVER_TAG. Returns the freshly installed
        executable path, or `current` when nothing was needed or the
        install failed (non-fatal: whatever is installed still works).
        `_AbortRequested` propagates.

        The archive carries both the executable and the library-mode
        companion, so this is also what refreshes a stale
        `librivulet-engine.so` -- `_dispatch_unsupervised()` calls it
        directly for `server_force_library`, which never resolves an
        executable to hand to `_upgrade_bundled_if_stale()`."""
        from lib import serverbin

        bin_dir = serverbin.install_dir(self.profile_dir, ADDON_ID)
        installed = serverbin.installed_tag(bin_dir)
        if serverbin.SERVER_TAG in (installed, serverbin.attempted_tag(bin_dir)):
            # `attempted_tag` covers a device that denies exec() (SELinux
            # on Android): the archive was already fetched once for this
            # tag, and fetching it again every Kodi start cannot help.
            return current

        self._info(
            f"upgrading rivulet-engine binary from {installed or 'an unstamped install'} "
            f"to {serverbin.SERVER_TAG}")
        self._notify(30069)
        try:
            return serverbin.install_binary(
                bin_dir, progress_cb=self._abort_progress, sleep_fn=self._abort_aware_sleep)
        except _AbortRequested:
            raise
        except Exception as exc:  # noqa: BLE001 - a stale install still works; never block the spawn
            self._warn(
                f"rivulet-engine binary upgrade to {serverbin.SERVER_TAG} failed: {exc}, "
                f"keeping the installed one")
            return current

    def _note_server_mode(self, state, mode):
        """Log, once per change, that streaming goes through a server this
        addon does not own: the torrent-engine/proxy settings
        (`EXTRA_ENV_SETTINGS`) are handed to the server as environment
        variables at spawn time and never reach an external one."""
        if state.server_mode == mode:
            return
        state.server_mode = mode
        target = server_url_for_log(self.monitor.server_url)
        if mode == "disabled":
            self._info(
                f"embedded server disabled (server_enable is off): streaming through the server at {target}; "
                f"the torrent-engine/proxy settings are not applied to it")
        else:
            self._info(
                f"using the rivulet-engine already listening at {target} instead of spawning one; "
                f"the torrent-engine/proxy settings are not applied to it")

    # -- Phase B ----------------------------------------------------------

    def tick_progress_and_restart(self, state):
        """Sample playback progress, then apply a pending settings-changed
        restart. Runs once per loop tick, before `dispatch()`."""
        try:
            self.progress_player.sample_if_playing()
        except Exception as exc:  # noqa: BLE001 - playback-progress sampling must never crash the service loop
            self._warn("progress sampling failed: %r" % (exc,))

        if self.monitor.restart_requested:
            self.monitor.restart_requested = False
            if state.proc is not None:
                self._info("settings changed, restarting embedded server")
                if self._stop_process(state.proc):
                    state.proc = None
            state.backoff_idx = 0
            state.server_mode = None
            state.notified_missing = False
            state.unsupported_platform = False
            state.reset_download()

    # -- Phase C ----------------------------------------------------------

    def dispatch(self, state):
        """Enabled/healthy/nothing-running dispatch, including binary
        resolve/auto-download/upgrade. Returns `(interval, should_break)`;
        `should_break` is True when an in-flight `_AbortRequested` must
        unwind the loop straight past the autoload tick and
        `waitForAbort()`, since Kodi is already shutting down."""
        if not self.monitor.enabled:
            self._dispatch_disabled(state)
            return IDLE_POLL_INTERVAL, False
        if state.proc is not None:
            return self._dispatch_supervised(state), False
        return self._dispatch_unsupervised(state)

    def _dispatch_disabled(self, state):
        self._note_server_mode(state, "disabled")
        if state.proc is not None:
            self._info("embedded server disabled, stopping")
            if self._stop_process(state.proc):
                state.proc = None

    def _dispatch_supervised(self, state):
        code = state.proc.poll()
        if code is None:
            state.server_mode = "embedded"
            state.proc.maybe_rotate_log()
            return HEALTHY_POLL_INTERVAL
        if (state.proc.uptime() or 0) >= MIN_STABLE_UPTIME:
            state.backoff_idx = 0
        self._warn(f"embedded server exited (code {code}), restarting")
        interval = self._backoff_interval(state)
        if self._stop_process(state.proc):
            state.proc = None
        return interval

    def _dispatch_unsupervised(self, state):
        """Nothing of ours running: prefer an already-reachable instance
        (external or manually started) over spawning a duplicate. The probe
        runs every iteration regardless of the unsupported_platform latch,
        because "point Server URL at a server running elsewhere" is the
        documented remedy for that latch."""
        monitor = self.monitor
        if probe_listening(monitor.server_url):
            state.notified_missing = False
            self._note_server_mode(state, "external")
            return EXTERNAL_RECHECK_INTERVAL, False
        if monitor.force_library:
            # Explicit opt-out of the exec()-based path (see
            # `server_force_library` in settings.xml): skip
            # resolve_binary()/install_binary() and go straight to
            # c-shared library mode whenever a companion .so is on disk.
            library_path = self._resolve_library_candidate()
            if library_path is not None:
                if not state.upgrade_attempted:
                    # The executable path's stale-tag check never runs in
                    # this mode, so without it a librivulet-engine.so from
                    # an older SERVER_TAG would be loaded forever.
                    state.upgrade_attempted = True
                    try:
                        self._reinstall_if_stale(None)
                    except _AbortRequested:
                        self._info("rivulet-engine library upgrade aborted, shutting down")
                        return IDLE_POLL_INTERVAL, True
                state.notified_missing = False
                state.unsupported_platform = False
                state.proc, interval = self._start_library_server(library_path, state)
                return interval, False
        if state.unsupported_platform:
            return self._dispatch_unsupported(state), False
        return self._dispatch_binary(state)

    def _dispatch_unsupported(self, state):
        """Latched branch: the same detection work as `_dispatch_binary()`
        -- just resolve_binary(), no fresh install attempt -- at the
        coarser UNSUPPORTED_PLATFORM_POLL_INTERVAL cadence."""
        interval = UNSUPPORTED_PLATFORM_POLL_INTERVAL
        library_path = self._resolve_library_candidate()
        if library_path is not None:
            # Self-heal into library mode: a companion .so is now on disk
            # and ctypes works here; prefer it over the exec() path, which
            # keeps failing for the same reason on an enforcing-SELinux
            # device.
            state.notified_missing = False
            return self._start_library_with_exec_fallback(state, library_path)
        binary = resolve_binary(self.monitor.binary_setting, self.profile_dir)
        if binary is None:
            if not state.notified_missing:
                self._notify(30031, error=True)
                self._error("rivulet-engine binary not found")
                state.notified_missing = True
            return interval
        # Self-heal: a runnable binary appeared (or a noexec/EACCES mount
        # condition cleared) without any Kodi setting changing.
        state.notified_missing = False
        state.unsupported_platform = False
        state.proc, interval = self._start_embedded_server(binary, state)
        return interval

    def _dispatch_binary(self, state):
        binary = resolve_binary(self.monitor.binary_setting, self.profile_dir)
        if binary is None:
            return self._dispatch_missing_binary(state)
        state.notified_missing = False
        state.unsupported_platform = False
        state.reset_download()
        # Before spawning: a binary installed under an older SERVER_TAG is
        # upgraded in place, since install_binary() is otherwise only
        # reached via the binary-is-None branch. Checked here rather than
        # at startup so it can never race a server we already have running.
        try:
            binary = self._upgrade_bundled_if_stale(binary, state)
        except _AbortRequested:
            self._info("rivulet-engine binary upgrade aborted, shutting down")
            return IDLE_POLL_INTERVAL, True
        state.proc, interval = self._start_embedded_server(binary, state)
        if state.proc is None and is_bundled_binary(binary, self.profile_dir):
            # install_binary() promotes an unverified executable even when
            # verify_executable() failed, so a leftover binary that still
            # cannot exec() (SELinux W^X, noexec mount, ...) would
            # spawn-fail forever with library mode never tried. Fall back
            # when a companion .so is already on disk.
            library_path = self._resolve_library_candidate()
            if library_path is not None:
                self._info(
                    "rivulet-engine executable failed to spawn, "
                    "falling back to library mode")
                state.proc, interval = self._start_library_server(library_path, state)
        return interval, False

    def _dispatch_missing_binary(self, state):
        interval = MISSING_BINARY_RECHECK_INTERVAL
        if state.next_download_at is not None and self._clock() < state.next_download_at:
            # Still cooling down from the last failed attempt -- gated on a
            # monotonic deadline (not just this iteration's sleep) so no
            # combination of other branches can retry early.
            return interval, False
        return self._auto_download(state, interval)

    def _auto_download(self, state, interval):
        if not state.download_attempt_notified:
            self._notify(30069)
            state.download_attempt_notified = True
        self._info("auto-downloading rivulet-engine binary")
        from lib import serverbin

        try:
            serverbin.install_binary(
                serverbin.install_dir(self.profile_dir, ADDON_ID),
                progress_cb=self._abort_progress,
                sleep_fn=self._abort_aware_sleep,
            )
        except _AbortRequested:
            # Not a failure -- Kodi is shutting down. No error
            # notification, and unwind the loop right away instead of
            # waiting on abort again.
            self._info("rivulet-engine binary download aborted, shutting down")
            return interval, True
        except serverbin.UnsupportedPlatformError as exc:
            return self._on_download_unsupported(state, exc, interval), False
        except Exception as exc:
            self._on_download_failed(state, exc)
            return interval, False
        self._info("rivulet-engine binary download complete")
        state.reset_download()
        return POST_DOWNLOAD_RECHECK_INTERVAL, False

    def _on_download_unsupported(self, state, exc, interval):
        library_path = self._resolve_library_candidate()
        if library_path is None:
            state.unsupported_platform = True
            state.next_download_at = None
            self._warn(f"rivulet-engine binary cannot run on this device: {exc}")
            self._notify(30091, error=True)
            return interval
        # install_binary() extracts the optional librivulet-engine.so
        # companion regardless of whether the executable itself passed
        # verify_executable(), so a fresh SELinux-enforcing failure can fall
        # back to c-shared library mode immediately instead of latching.
        self._info(
            f"rivulet-engine executable unsupported ({exc}), "
            f"falling back to library mode")
        state.notified_missing = False
        interval = self._start_library_with_exec_fallback(state, library_path)
        state.next_download_at = None
        return interval

    def _on_download_failed(self, state, exc):
        # Transient failure (network hiccup, GitHub outage, no release
        # asset yet, ...): retry after a bounded backoff, but only surface
        # the failure notification once per cycle so a prolonged outage
        # does not spam the user.
        wait_s = DOWNLOAD_RETRY_BACKOFF[
            min(state.download_backoff_idx, len(DOWNLOAD_RETRY_BACKOFF) - 1)
        ]
        state.download_backoff_idx = min(
            state.download_backoff_idx + 1, len(DOWNLOAD_RETRY_BACKOFF) - 1
        )
        state.next_download_at = self._clock() + wait_s
        self._error(f"rivulet-engine binary download failed: {exc}, retrying in {wait_s}s")
        if not state.download_failure_notified:
            self._notify(30063, error=True)
            state.download_failure_notified = True

    # -- loop -------------------------------------------------------------

    def _autoload_interval(self, interval):
        """Autoload runs last, so it sees this iteration's `interval` and
        can shorten it: the supervision branches may have picked a sleep
        far longer than the launch is meant to wait."""
        autoload = self.autoload
        if autoload.fired:
            return interval
        try:
            autoload_interval = autoload.poll(self._clock())
        except Exception as exc:  # noqa: BLE001 - autoload must never crash the supervision loop
            self._error("startup autoload failed: %r" % (exc,))
            autoload.fired = True  # latch off; never retry for the rest of the session
            return interval
        if autoload_interval is not None:
            return min(interval, autoload_interval)
        return interval

    def run(self):
        """Supervise until Kodi aborts. `shutdown()` runs in `finally`: an
        exception escaping any tick (a failed notification, an import
        error while resolving the library companion, ...) would otherwise
        kill this thread with the embedded rivulet-engine still bound to
        its port and the S4Me bridge never told to stop -- the next Kodi
        start would then adopt that orphan as an "external" server and
        never apply new settings to it."""
        state = self.state
        monitor = self.monitor
        try:
            while not monitor.abortRequested():
                self.tick_progress_and_restart(state)
                self._sync_bridge()

                interval, should_break = self.dispatch(state)
                if should_break:
                    break

                interval = self._autoload_interval(interval)
                if monitor.waitForAbort(interval):
                    break
        finally:
            self.shutdown()

    def shutdown(self):
        # Kodi never delivers the abort to the RunScript-launched bridge in
        # time (it was observed still polling waitForAbort() well after
        # "Stopping the application", then hung Kodi's quit). This service
        # does see the abort, so it tells the bridge to stop itself.
        try:
            self._shutdown_bridge()
        except Exception as exc:  # noqa: BLE001 - shutdown must continue regardless
            self._warn("s4me bridge shutdown failed: %r" % (exc,))

        if self.state.proc is not None:
            self._info("shutting down embedded server")
            self._stop_process(self.state.proc)

        # Last: the final push of a playback that ended with Kodi runs on a
        # daemon thread that would otherwise die with the interpreter.
        try:
            if not self.progress_player.drain_pushes(PUSH_DRAIN_SECONDS):
                self._warn("progress push still in flight at shutdown, giving up on it")
        except Exception as exc:  # noqa: BLE001 - shutdown must finish regardless
            self._warn("progress push drain failed: %r" % (exc,))


def main():
    """Entry point for service.py: xbmc.Monitor-driven supervision loop."""
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs

    addon = xbmcaddon.Addon()
    profile_dir = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
    os.makedirs(profile_dir, exist_ok=True)

    def log(level, message):
        xbmc.log(f"[{ADDON_ID}] {message}", level)

    def notify(string_id, error=False):
        if error:
            xbmcgui.Dialog().notification(
                addon.getAddonInfo("name"),
                addon.getLocalizedString(string_id),
                xbmcgui.NOTIFICATION_ERROR,
            )
        else:
            xbmcgui.Dialog().notification(
                addon.getAddonInfo("name"), addon.getLocalizedString(string_id),
            )

    def _launch_addon_ui():
        log(xbmc.LOGINFO, "startup autoload: opening Rivulet")
        try:
            xbmc.executebuiltin(AUTOLOAD_BUILTIN)
        except Exception as exc:  # noqa: BLE001 - a failed launch must never crash the supervision loop
            log(xbmc.LOGERROR, f"startup autoload failed: {exc}")

    autoload = AutoloadTrigger(
        gui_ready_fn=lambda: bool(xbmc.getCondVisibility("Window.IsVisible(home)")),
        launch_fn=_launch_addon_ui,
        started_at=time.monotonic(),
        disabled=not _settings.setting_bool(addon, "startup_autoload", False),
    )

    store = Store(profile_dir)
    sync_enabled = lambda: _settings.setting_bool(addon, "sync_progress", True)  # noqa: E731
    progress_player = build_progress_player(xbmc, store, StremioAPI(), log, sync_enabled)
    # Own client: the player pushes from Kodi's callback thread too, and a
    # requests.Session is not safe to share across threads.
    abort_monitor = xbmc.Monitor()
    progress_puller = ProgressPuller(
        store, StremioAPI(), log, LogLevels(xbmc.LOGINFO, xbmc.LOGWARNING, xbmc.LOGERROR),
        sync_enabled, lambda: progress_player.isPlaying(), lambda: abort_monitor.abortRequested(),
    )

    # S4Me bridge: deliberately independent of ServiceMonitor -- reads its
    # own settings fresh every call, and BridgeSupervisor.apply() is cheap
    # and idempotent, so calling this every supervision tick is fine.
    s4me_bridge = s4me.BridgeSupervisor(addon.getAddonInfo("path"))

    italian_cache = {"ticks_left": 0, "value": False}

    def is_italian_user_cached():
        # getLanguage + a Settings.GetSettingValue JSON-RPC round trip are
        # pointless to repeat every tick: the answer only changes when the
        # user edits Kodi's language settings, which a few minutes' lag
        # absorbs without anyone noticing. Counted in ticks, not seconds,
        # because the loop's sleep varies by branch.
        if italian_cache["ticks_left"] <= 0:
            italian_cache["value"] = _detect_italian_user(xbmc)
            italian_cache["ticks_left"] = ITALIAN_USER_RECHECK_TICKS
        italian_cache["ticks_left"] -= 1
        return italian_cache["value"]

    def sync_s4me_bridge():
        try:
            # Stream4Me's channels are Italian-language sites: the bridge
            # only runs for Italian users who also have Stream4Me
            # installed. s4me_enable defaults to on, so for those users it
            # is active without setup; the setting (hidden from everyone
            # else by settings.xml) lets them turn it off. Installed-ness
            # is checked first: it is one cheap builtin, and most users
            # lack Stream4Me, so they never pay for the language lookup.
            has_addon = bool(xbmc.getCondVisibility("System.HasAddon(%s)" % s4me.S4ME_ADDON_ID))
            enabled = (
                has_addon
                and _settings.setting_bool(addon, "s4me_enable", True)
                and is_italian_user_cached()
            )
            s4me_bridge.apply(
                enabled,
                _settings.setting_int(addon, "s4me_port", s4me.DEFAULT_PORT),
                lambda: has_addon,
                xbmc.executebuiltin,
                store,
                log_fn=lambda message: log(xbmc.LOGWARNING, "s4me bridge: %s" % message),
            )
        except Exception as exc:  # noqa: BLE001 - a bridge sync failure must never crash the service loop
            log(xbmc.LOGWARNING, f"s4me bridge sync failed: {exc}")

    def periodic_sync():
        sync_s4me_bridge()
        progress_puller.poll()

    def shutdown_s4me_bridge():
        bridge_port = s4me_bridge.launched_port()
        if bridge_port is not None:
            s4me.shutdown_bridge(bridge_port)

    # Mix the Kodi Monitor in here: xbmc cannot be imported at module scope.
    monitor_cls = type("KodiServiceMonitor", (ServiceMonitor, xbmc.Monitor), {})
    Supervisor(
        monitor_cls(addon),
        profile_dir,
        log,
        LogLevels(xbmc.LOGINFO, xbmc.LOGWARNING, xbmc.LOGERROR),
        notify,
        progress_player,
        periodic_sync,
        shutdown_s4me_bridge,
        autoload,
    ).run()
